package StudentSwap;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.TreeMap;

import Model.Students;
import Model.Teams;
import Model.TeamsModel;
import consoleDataEntry.Utility;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.fxml.Initializable;

/*
 * This is controller class for the GUI. requests information from the TeamsModel based on user interaction and 
 * updates as required. 
 * 
 * @Author: Luke Howard
 * @Date: 13/10/2020
 */
public class StudentSwapController{
	private TeamsModel tm;
	ArrayList<CheckBox> CBList = new ArrayList<CheckBox>();
    @FXML private CheckBox team1_mem1;
    @FXML private CheckBox team1_mem2;
    @FXML private CheckBox team1_mem3;
    @FXML private CheckBox team1_mem4;
    @FXML private CheckBox team2_mem2;
    @FXML private CheckBox team2_mem1;
    @FXML private CheckBox team2_mem3;
    @FXML private CheckBox team2_mem4;
    @FXML private CheckBox team3_mem1;
    @FXML private CheckBox team3_mem2;
    @FXML private CheckBox team3_mem3;
    @FXML private CheckBox team3_mem4;
    @FXML private CheckBox team4_mem1;
    @FXML private CheckBox team4_mem2;
    @FXML private CheckBox team4_mem3;
    @FXML private CheckBox team4_mem4;
    @FXML private CheckBox team5_mem1;
    @FXML private CheckBox team5_mem2;
    @FXML private CheckBox team5_mem3;
    @FXML private CheckBox team5_mem4;
    @FXML private VBox Team1;
    @FXML private VBox Team2;
    @FXML private VBox Team3;
    @FXML private VBox Team4;
    @FXML private VBox Team5;
    @FXML private BarChart<?, ?> PPbarchart;
    @FXML private BarChart<?, ?> SKbarchart;
    @FXML private BarChart<?, ?> SCbarchart;
    @FXML private TextField IDtoFind;
    @FXML private TextField teamToFind;
    @FXML private TextArea suggestedStudents;
    @FXML private Text personality;
    @FXML private Text conflicts;
    @FXML private Text marks;
    @FXML private Text preferences;
    @FXML private TextArea teamInformation;
    @FXML private Button undo;
	
    @FXML
    public void initialize() {
		tm = new TeamsModel();
		tm.setController(this);
		createCheckBoxList();
    	updateTeamMembers();
    	updateGraphs();
    	try {
			tm.startThread();
		} catch (InterruptedException e) {
			System.err.println("Unable to suggest swaps. Error occured");
		}
    }
	
	 private void createCheckBoxList() {
		CBList.add(team1_mem1);
		CBList.add(team1_mem2);
		CBList.add(team1_mem3);
		CBList.add(team1_mem4);
		CBList.add(team2_mem1);
		CBList.add(team2_mem2);
		CBList.add(team2_mem3);
		CBList.add(team2_mem4);
		CBList.add(team3_mem1);
		CBList.add(team3_mem2);
		CBList.add(team3_mem3);
		CBList.add(team3_mem4);
		CBList.add(team4_mem1);
		CBList.add(team4_mem2);
		CBList.add(team4_mem3);
		CBList.add(team4_mem4);
		CBList.add(team5_mem1);
		CBList.add(team5_mem2);
		CBList.add(team5_mem3);
		CBList.add(team5_mem4);
	}

	@FXML
	public void getStudent(ActionEvent evt) {
		 String ID =  IDtoFind.getText().toUpperCase();
		 Students stud = tm.getStudID(ID);
  	   if (tm.getStudID(ID) == null){
  		   Alert alert = new Alert(AlertType.ERROR);
  		   IDtoFind.setText(null);
  		   alert.setTitle("Error Dialog");
  		   alert.setHeaderText("Student with this ID does not exist");
  		   alert.setContentText("Enter an existing ID");
  		   alert.showAndWait(); 		     
  	   }
  	   else {
         preferences.setText(stud.getPref1()+" "+stud.getPref2()+" "+stud.getPref3()+" "+stud.getPref4());
         personality.setText(Character.toString(stud.getPersonality()));
         conflicts.setText(stud.getConflict1()+" "+stud.getConflict2());
         marks.setText("Ana: "+stud.getAnaGrade()+" Net: "+stud.getNetGrade()+" Web: "+stud.getWebGrade()+
        		 " Prog: "+stud.getProgGrade());
  	   }
	 }
	
	 public void getStudentEnter(KeyEvent evt) {
		 if(evt.getCode() == KeyCode.ENTER) {
		 String ID =  IDtoFind.getText().toUpperCase();
		 Students stud = tm.getStudID(ID);
		 if (tm.getStudID(ID) == null){
  		   Alert alert = new Alert(AlertType.ERROR);
  		   IDtoFind.setText(null);
  		   alert.setTitle("Error Dialog");
  		   alert.setHeaderText("Student with this ID does not exist");
  		   alert.setContentText("Enter an existing ID");
  		   alert.showAndWait(); 		     
  	   	}
  	   	else {
         preferences.setText(stud.getPref1()+" "+stud.getPref2()+" "+stud.getPref3()+" "+stud.getPref4());
         personality.setText(Character.toString(stud.getPersonality()));
         conflicts.setText(stud.getConflict1()+" "+stud.getConflict2());
         marks.setText("Ana: "+stud.getAnaGrade()+" Net: "+stud.getNetGrade()+" Web: "+stud.getWebGrade()+
        		 " Prog: "+stud.getProgGrade());
  	    		}
		 }
	 }
	 
	 public void updateTeamMembers() {
		 updateTeam1();
		 updateTeam2();
		 updateTeam3();
		 updateTeam4();
		 updateTeam5();
	 }
	 
	 public void resetCheckBoxes() {
		 for(CheckBox c : CBList) {
			 c.setSelected(false);
		 }
	 }
	

	public void updateTeam1() {
		 String teamToFind = "Team1";
		 String [] members = tm.getMembers(teamToFind);	
		 team1_mem1.setText(members[0]);
	     team1_mem2.setText(members[1]);
	     team1_mem3.setText(members[2]);
	     team1_mem4.setText(members[3]);
	}
	 
	private void updateTeam2() {
		 String teamToFind = "Team2";
		 String [] members = tm.getMembers(teamToFind);	
		 team2_mem1.setText(members[0]);
	     team2_mem2.setText(members[1]);
	     team2_mem3.setText(members[2]);
	     team2_mem4.setText(members[3]);	
	}
	 
	private void updateTeam3() {
		 String teamToFind = "Team3";
		 String [] members = tm.getMembers(teamToFind);	
		 team3_mem1.setText(members[0]);
	     team3_mem2.setText(members[1]);
	     team3_mem3.setText(members[2]);
	     team3_mem4.setText(members[3]);
	}
	
	private void updateTeam4() {
		 String teamToFind = "Team4";
		 String [] members = tm.getMembers(teamToFind);	
		 team4_mem1.setText(members[0]);
	     team4_mem2.setText(members[1]);
	     team4_mem3.setText(members[2]);
	     team4_mem4.setText(members[3]);	
	}
	
	private void updateTeam5() {
		 String teamToFind = "Team5";
		 String [] members = tm.getMembers(teamToFind);	
		 team5_mem1.setText(members[0]);;
	     team5_mem2.setText(members[1]);
	     team5_mem3.setText(members[2]);
	     team5_mem4.setText(members[3]);
	}
	 
	public void updateGraphs() {
		 Map<String,Double> series1 = new TreeMap<String,Double>();
		HashMap<String, Teams> currentTeams = tm.getCurrentTeams();
		for(Map.Entry<String,Teams> m: currentTeams.entrySet()) {
			Teams team = m.getValue();
			series1.put(team.getTeamID(),tm.getPP(team.getTeamID()));
		}
		 XYChart.Series dataSeries1  = new XYChart.Series();
	        
	      for (String c : series1.keySet() )
	          dataSeries1.getData().add(new XYChart.Data(c, series1.get(c))); 
	     PPbarchart.getData().clear();
	     PPbarchart.getData().add(dataSeries1);	
	     PPbarchart.setTitle("Percentage Preferences\n"
	     		+ "\tstdev: "+tm.calPPstdev());
		 
	     
	     Map<String,Double> series2 = new TreeMap<String,Double>();
	     for(Map.Entry<String,Teams> m: currentTeams.entrySet()) {
				Teams team = m.getValue();
				series2.put(team.getTeamID(),tm.getSS(team.getTeamID()));
			}
		 XYChart.Series dataSeries2  = new XYChart.Series();
	        
	      for (String c : series2.keySet() )
	          dataSeries2.getData().add(new XYChart.Data(c, series2.get(c))); 
	     SKbarchart.getData().clear();
	     SKbarchart.getData().add(dataSeries2);
	     SKbarchart.setTitle("Skill Shortfall\n"
	     		+ "\tstdev: "+tm.calSKdev());
	     
	     Map<String,Double> series3 = new TreeMap<String,Double>();
	     for(Map.Entry<String,Teams> m: currentTeams.entrySet()) {
				Teams team = m.getValue();
				series3.put(team.getTeamID(),tm.getSC(team.getTeamID()));
			}
		 XYChart.Series dataSeries3  = new XYChart.Series();
	        
	      for (String c : series2.keySet() )
	          dataSeries3.getData().add(new XYChart.Data(c, series3.get(c))); 
	     SCbarchart.getData().clear();
	     SCbarchart.getData().add(dataSeries3);
	     SCbarchart.setTitle("Skill Competency\n"
		     		+ "\tstdev: "+tm.calSCdev());   
	 }
	
	@FXML
	 public void StudentsToSwap(ActionEvent evt) {
		 try {
		 String ID =  ((CheckBox)evt.getSource()).getText().substring(0,3).strip();
		 Students member = tm.getStudID(ID);
		 if(tm.removeMember(member) == false) {
			 tm.addToSwap(member);
		 }
		 else {
			 ((CheckBox)evt.getSource()).setSelected(false);
		 }
		 
		 }
		 catch(Exception e) {
			 resetCheckBoxes();
			 tm.removeAll();
			 Alert alert = new Alert(AlertType.ERROR, "Invalid Selection", ButtonType.OK);
	  		   alert.setTitle("Too Many Students Selected");
	  		   alert.setHeaderText("Cannot swap this many students");
	  		   alert.setContentText("Select only two students to swap");
	  		   alert.showAndWait(); 
	  		   
		 	}
	  }
	
	@FXML
	 public void SwapMembers(ActionEvent evt) {
		try {
		if(tm.checkSameTeam() == true) {
			resetCheckBoxes();
			 tm.removeAll();
			 Alert alert = new Alert(AlertType.ERROR, "Invalid Selection", ButtonType.OK);
	  		   alert.setTitle("Same Team Selected");
	  		   alert.setHeaderText("Cannot swap students in the same team");
	  		   alert.setContentText("Please select students in different teams to swap");
	  		   alert.showAndWait(); 
	  		   return;
		}
		if(tm.checkLeader() == true) {
			resetCheckBoxes();
			 tm.removeAll();
			 Alert alert = new Alert(AlertType.ERROR, "No Leader", ButtonType.OK);
	  		   alert.setTitle("No Leader Present");
	  		   alert.setContentText("All teams must contain at least one leader personality ");
	  		   alert.showAndWait(); 
	  		   return;
		}
		if(tm.checkPeronalities() == true) {
			resetCheckBoxes();
			 tm.removeAll();
			 Alert alert = new Alert(AlertType.ERROR, "Too Few Personalities", ButtonType.OK);
	  		   alert.setTitle("To few personalities");
	  		   alert.setContentText("All teams must contain at least three different personality types ");
	  		   alert.showAndWait();
	  		   return;
		}
		 tm.checkMembers();
		 updateGraphs();
		 updateTeamMembers();
		 tm.writeTeams();
		 tm.writeDB();
		 resetCheckBoxes();
		 tm.removeAll();
		 }
		 catch (Exception e) {
			 Alert alert = new Alert(AlertType.ERROR, "Invalid Swap", ButtonType.YES,ButtonType.NO);
	  		   alert.setTitle("Possible Student Conflict");
	  		   alert.setHeaderText("Swapping these students may will result in conflict");
	  		   alert.setContentText("Would you like to proceed with swap anyway?");
	  		 Optional <ButtonType> result = alert.showAndWait();
	  		if(result.get() == ButtonType.YES) {
	  			tm.swapMembersGUI(); 
	  			updateGraphs();
	  			updateTeamMembers();
	  			resetCheckBoxes();
	  			tm.writeTeams();
	  			tm.writeDB();
	  			tm.removeAll();
	  		}
	  		else if(result.get() == ButtonType.NO) {
	  			resetCheckBoxes();
				tm.removeAll();
	  		}
	
		 	}
	    }
	 
	public void suggestMembers() {
		 try {
			 String ID = teamToFind.getText();	
			 Teams teamToPrint = tm.getTeam(ID);
		ArrayList<Students> suggested =	 tm.suggestedStudents(teamToPrint);
		String suggestedIDs = "Suggested Members for selected team:";
		
		for(Students s : suggested) {
			suggestedIDs = suggestedIDs+"\n"+s.getStud();
		}
			 teamInformation.setText((tm.printTeam(teamToPrint)));
			 suggestedStudents.setText(suggestedIDs);
			 
			 }
			 catch(NullPointerException e) {
				 Alert alert = new Alert(AlertType.ERROR);
				 teamToFind.setText(null);
		  		   alert.setTitle("Team Error");
		  		   alert.setHeaderText("Team does not exist");
		  		   alert.setContentText("Please enter a valid team ID");
		  		   alert.showAndWait(); 
			 }
	 }
	
	@FXML
	 public void getSuggested(ActionEvent event) {
		suggestMembers();
	 }
	
	@FXML
	 public void getSuggestedEnter(KeyEvent keyPressed) {
		 if(keyPressed.getCode() == KeyCode.ENTER) {
			 suggestMembers();
		 }
	 }
	
	public void undoChanges (ActionEvent evt) {
		if(tm.checkUndoSize()==0) {
			 Alert alert = new Alert(AlertType.ERROR, "Nothing to undo", ButtonType.OK);
	  		   alert.setTitle("No swaps to undo at this time");
	  		   alert.showAndWait();
	  		   return;
		}
		 tm.undo();
		 updateGraphs();
		 updateTeamMembers();
		 resetCheckBoxes();
		 tm.writeTeams();
		 tm.writeDB();
		 tm.removeAll();
	 }
 }

