package Model;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.TreeMap;

/*
 * Contains methods related to reading/ writing text files of project, owner, company and student objects. Also 
 * contains methods to serialize teams and student objects. 
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */

public class ReadWrite {
	public ReadWrite() {
		
	}
	
//	following methods write specified object to file/ serialize using appropriate writer
	public void writeCompanies (HashMap<String, Company> totalCompany){
		try {
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("companies.txt",true)));
		for (Map.Entry<String, Company> m : totalCompany.entrySet()) {
			Company c = m.getValue();
			pw.println(c.print());
		}
		System.out.println("Generated file successfully");
		pw.close();
		}
		
		catch(IOException e) {
			System.err.println("Unable to write companies.txt");
			}
		}
	
	public void writeProject(Project p) {
		try {
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("projects.txt",true)));
			pw.println(p.print());
		
		System.out.println("Generated file successfully");
		pw.close();
		}
		
		catch(IOException e) {
			System.err.println("Unable to write projects.txt");
			}
		}
	
	public void writeProject(TreeMap<Project, Integer> toPrint) {
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("projects_final.txt")));
			
			for (Map.Entry<Project, Integer> m : toPrint.entrySet()) {
			Project proj = m.getKey();
			pw.println(proj.print());
			pw.println();
				}
			pw.close();
			System.out.println("Projects have been shortlisted");
		    }
			
		catch(IOException e) {
				System.err.println("Unable to write projects.txt");
			}
	}
	
	public void writeProject(HashMap<String, Project> projects) {
		try {
		ObjectOutputStream objectOutput = new ObjectOutputStream(new FileOutputStream("projects.dat"));
		objectOutput.writeObject(projects);
		objectOutput.close();
		}
		
		catch(IOException e) {
			System.err.println("Unable to serialise projects");
		}
	}
	
	public void writeFinalProject(ArrayList<Project> finalProjects) {
		try {
		ObjectOutputStream objectOutput = new ObjectOutputStream(new FileOutputStream("finalprojects.dat"));
		objectOutput.writeObject(finalProjects);
		objectOutput.close();
		}
		
		catch(IOException e) {
			System.err.println("Unable to serialise projects");
		}
	}
	
	public void writeInterviewedStudents(HashMap<String, Students> interviewedStudents) {
		try {
			ObjectOutputStream objectOutput = new ObjectOutputStream(new FileOutputStream("interviewedStudents.dat"));
			objectOutput.writeObject(interviewedStudents);
			objectOutput.close();
			}
			
		catch(IOException e) {
				System.err.println("Unable to serialise projects");
			}
	}
	
	public void writeTeams(HashMap<String, Teams> totalTeams) {
		try {
			ObjectOutputStream objectOutput = new ObjectOutputStream(new FileOutputStream("teams.dat"));
			objectOutput.writeObject(totalTeams);
			objectOutput.close();
			}
			
		catch(IOException e) {
				System.err.println("Unable to serialise teams");
			}
	}
	
	public void writeTeamstxt(HashMap<String, Teams> totalTeams) {
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("teams.txt")));
			
			for (Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			Teams team = m.getValue();
			pw.println(team.print());
				}
			pw.close();
			System.out.println("Teams file has been generated");
		    }
			
		catch(IOException e) {
				System.err.println("Unable to write teams.txt");
			}
	}
	
	public void writeStudInfo(Students s) {
		try {
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("studentinfo.txt",true)));
		    pw.println(s.print());
			System.out.println("Generated file successfully");
			pw.close();
		}
		catch(IOException e){
			System.err.println("Unable to write studentinfo.txt");
			}
		}

	public void writeStudPref(Students student){
		try {
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("preferences.txt",true)));
			pw.println(student.printPref());
		
			System.out.println("Generated file successfully");
		pw.close();
		}	
		catch (IOException e) {
			System.err.println("Unable to write preferences.txt");
			}
		}
	
	public void writeOwner(HashMap<String, Owner> totalOwners) {
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("owners.txt",true)));
			for (Map.Entry<String, Owner> m : totalOwners.entrySet()) {
				Owner o = m.getValue();
				pw.println(o.print());
			}
			System.out.println("File succesfully written");
			pw.close();
			}
			
		catch(IOException e) {
				System.err.println("Unable to write owners.txt");
			}
		
		}
	
//	method used to check if a student has already entered a preference by scanning txt file for student ID
	public boolean checkPrefID(Students ID) throws IOException {
		boolean found = false;
		String IDtoFind = ID.getStud();
		System.out.println("Finding "+ID.getStud()+"...");
		
		try {
		Scanner input = new Scanner (new File("preferences.txt"));
		if (input.hasNext() == true) {
			while(input.hasNext()) {
				if((input.next().equals(IDtoFind))){
					System.out.println("ID located preferences will now be updated");
					System.out.println();
					found = true;
					return true;
				} 
			}
		}
		}
		
//		if no file can be found, creates new preferences file
		catch (Exception e) {
			File newPref = new File("preferences.txt");
			newPref.createNewFile();
			System.err.println("No preferences entered new file generated");
			return found;
		}
		return found;
		}
	
//  checks if student has already been interviewed, returns true if ID is found in file	
	public boolean checkInterviewID(Students ID) throws IOException{
		boolean found = false;
		String IDtoFind = ID.getStud();
		System.out.println("Finding "+ID.getStud()+"...");
		try {
		Scanner input = new Scanner (new File("studentinfo.txt"));
		if (input.hasNext() == true) {
			while(input.hasNext()) {
				if((input.next().equals(IDtoFind))){
					System.out.println("ID located interview will now be updated");
					System.out.println();
					found = true;
					return true;
				} 
			 }
		}
		}
//		creates new file if one does not already exist in directory
		catch (Exception e) {
			File newPref = new File("studentinfo.txt");
			newPref.createNewFile();
			System.err.println("No Student interviews conducted. New file generated");
			return found;
		}
		return found;
	}
	
//	method copies old preferences file without the ID and preferences that need to be amended
	public void ammendPref(Students ID) throws IOException {
		String IDtoFind = ID.getStud();
		File temp = new File("temp.txt");
		File output = new File("preferences.txt");
		BufferedReader input = new BufferedReader (new FileReader("preferences.txt"));
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("temp.txt")));
		String currentLine;
		String data[];
		
		while((currentLine = input.readLine()) != null) {
			data = currentLine.split(" ");
			if(!data[0].equalsIgnoreCase(IDtoFind)) {
				pw.println(currentLine);
			}
		}
		pw.close();
		input.close();
		temp.renameTo(output);
		}
	
//	same purpose as above but for interviewed students
	public void ammendInterview(Students ID) throws IOException {
		String IDtoFind = ID.getStud();
		File temp = new File("temp.txt");
		File output = new File("studentinfo.txt");
		BufferedReader input = new BufferedReader (new FileReader("studentinfo.txt"));
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("temp.txt")));
		String currentLine;
		String data[];
		
		while((currentLine = input.readLine()) != null) {
			data = currentLine.split(" ");
			if(!data[0].equalsIgnoreCase(IDtoFind)) {
				pw.println(currentLine);
			}
		}
		pw.close();
		input.close();
		temp.renameTo(output);
	}
	
/*
 * method tracks and counts the number of each personality of entered students and let user know how many of each
 * personality type remain to be used
 */
	public void availablePersonality() throws IOException{
		BufferedReader input = new BufferedReader (new FileReader("studentinfo.txt"));
		String currentLine;
		String data[];
		int A = 0;
		int B = 0;
		int C = 0;
		int D = 0;
		
		while((currentLine = input.readLine()) != null) {
			data = currentLine.split(" ");
			if(data[9].equalsIgnoreCase("A")) {
				A++;
			}
			else if(data[9].equalsIgnoreCase("B")) {
				B++;
			}
			else if(data[9].equalsIgnoreCase("C")) {
				C++;
			}
			else if(data[9].equalsIgnoreCase("D")) {
				D++;
			}
		}
		System.out.println("A: "+A+" "+"B: "+B+" "+"C: "+C+" "+"D: "+D);
	}
	
//	methods below are used to populate collections of objects by deserializing 
	public HashMap<String, Teams> readTeams() {
		HashMap<String, Teams> totalTeams = null;
		try {
		ObjectInputStream input = new ObjectInputStream(new FileInputStream("teams.dat"));
		totalTeams =  (HashMap<String, Teams>) input.readObject();
		input.close();
		}
		catch (IOException e ) {
			System.err.println("Unable to read in teams");
			e.printStackTrace();
		}
		catch(Exception e) {
			System.err.println("An error occured adding teams");
			e.printStackTrace();
		}
		return totalTeams;
	}
	
	public HashMap<String, Students> readInterveiwed() {
		HashMap<String, Students> interviewedStudents = null;
		try {
			ObjectInputStream input = new ObjectInputStream(new FileInputStream("interviewedStudents.dat"));
			interviewedStudents =  (HashMap<String, Students>) input.readObject();
			input.close();
			}
			catch (IOException e ) {
				System.err.println("Unable to read interviewedStudents");
				e.printStackTrace();
			}
			catch(Exception e) {
				System.err.println("An error occured adding projects");
			}
		return interviewedStudents;
		}
	
	public HashMap<String, Project> readProjects() {
		HashMap<String, Project>totalProjects = null;
		try {
		ObjectInputStream input = new ObjectInputStream(new FileInputStream("projects.dat"));
		totalProjects =  (HashMap<String, Project>) input.readObject();
		input.close();
		return totalProjects;
		}
		catch (IOException e ) {
			System.err.println("Unable to read in projects");
			e.printStackTrace();
		}
		catch(Exception e) {
			System.err.println("An error occured adding projects");
			e.printStackTrace();
		}
		return totalProjects;
		}
	
	public ArrayList<Project> readFinalProjects() {
		ArrayList<Project> finalProjects  = null;
		try {
			ObjectInputStream input = new ObjectInputStream(new FileInputStream("finalProjects.dat"));
			finalProjects =  (ArrayList<Project>) input.readObject();
			input.close();
			}
			catch (IOException e ) {
				System.err.println("Unable to read in final projects");
				e.printStackTrace();
			}
			catch(Exception e) {
				System.err.println("An error occured adding projects");
				e.printStackTrace();
			}
		return finalProjects;
		}
	}
