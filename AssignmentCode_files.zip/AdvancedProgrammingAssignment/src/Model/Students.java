package Model;
import java.io.Serializable;

/*
 * contains all information regarding student objects. two different constructors are present depending on if 
 * student has already been interviewed or not. Print methods for both student objects and their preferences are 
 * contained here
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */
public class Students  implements Serializable  {
	private static final long serialVersionUID = -8640557298668672810L;
	private String studID;
	private int progGrade;
	private int netGrade;
	private int anaGrade;
	private int webGrade;
	private char personality = '-';
	private String stud1 = "Null";
	private String stud2 = "Null";
	private String pref1 = "4";
	private String pref2 = "3";
	private String pref3 = "2";
	private String pref4 = "1";
	
	public Students(String ID, int P, int N, int A, int W){
		studID = ID;
		progGrade = P;
		netGrade = N;
		anaGrade = A;
		webGrade = W;
	}
	
	public Students(String ID, int P, int N, int A, int W, String conf1, String conf2, String pref1, 
			String pref2, String pref3, String pref4, char person ) {
		studID = ID;
		progGrade = P;
		netGrade = N;
		anaGrade = A;
		webGrade = W;
		stud1 = conf1;
		stud2 = conf2;
		this.pref1 = pref1;
		this.pref2 = pref2;
		this.pref3 = pref3;
		this.pref4 = pref4;
		personality = person;
	}
// Accessor methods	
	public String getStud() {
		return studID;
	}
	
	public int getProgGrade() {
		return progGrade;
	}
	public int getNetGrade() {
		return netGrade;
	}
	
	public int getAnaGrade() {
		return anaGrade;
	}
	public int getWebGrade() {
		return webGrade;
	}
	
	public char getPersonality() {
		return personality;
	}
	
	public void setPersonality(char A) {
		this.personality = A;
	}
	public String getConflict1() {
		return stud1;
	}
	
	public void setConflict1(String A) {
		
		stud1 = A;
	}
	
	public String getConflict2() {
		return stud2;
	}
	
	public void setConflict2(String A) {
		stud2 = A;
	}
	
	public String getPref1() {
		return pref1;
	}

	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}

	public String getPref2() {
		return pref2;
	}

	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}

	public String getPref3() {
		return pref3;
	}

	public void setPref3(String pref3) {
		this.pref3 = pref3;
	}

	public String getPref4() {
		return pref4;
	}

	public void setPref4(String pref4) {
		this.pref4 = pref4;
	}

	public String print() {
		String A = getStud()+" "+"P "+getProgGrade()+" "+"N "+getNetGrade()+" "+"A "+getAnaGrade()+
				" "+"W "+getWebGrade()+" "+getPersonality()+" "+getConflict1()+" "+getConflict2();
		return A;
	}
	
	public void setPreferences(String A, String B, String C, String D) {
		pref1 = A;
		pref2 = B;
		pref3 = C;
		pref4 = D;
	}

	public String printPref() {
		String A =getStud()+" "+" "+getPref1()+" 4"+" "+getPref2()+" 3"+" "+getPref3()+" 2"+" "+getPref4()+
				" 1";
		return A;
	}

}
