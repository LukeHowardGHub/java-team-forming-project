package Model;
import java.io.Serializable;
import java.util.*;

/*
 * Company class stores all information regarding company objects input by user or by file if required. Also provides
 * a method for printing company objects. Able to be serialized
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */
public class Company  implements Serializable {
	private static final long serialVersionUID = 1L;
	private String ID;
	private String name;
	private String ABN;
	private String URL;
	private String address;
	private ArrayList<Owner> owner;
	
//	Company class constructor
	public Company (String ID, String name, String ABN, String URL, String address){
		this.ID = "C"+ID;
		this.name = name;
		this.ABN = ABN;
		this.URL = URL;
		this.address = address;
		owner = new ArrayList<Owner>();
	}
	
//	Company class accessor methods
	public String getID(){
		return ID;
	}
	
	public String getName(){
		return name;
	}
	
	public String getABN(){
		return ABN;
	}
	
	public String getURL(){
		return URL;
	}
	
	public String getAddress(){
		return address;
	}

//	Method to add project owner to companies ArrayList
	public void addOwner (Owner o){
		owner.add(o);
	}
	
	public String print() {
		String A = getID()+"\n"+getName()+"\n"+getABN()+
				"\n"+getURL()+"\n"+getAddress();
		return A;
	}
	
	
}
