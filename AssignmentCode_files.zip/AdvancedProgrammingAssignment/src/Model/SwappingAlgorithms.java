package Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
/*
 * This class is used to calculate suggested swaps based on student percentage preferences, skill competency 
 * and skill shortage of individual teams. Prints a list of suggested swaps to improve each metric individually,
 * allowing user to determine which metric to improve depending on individual preference. Each algorithm is run through
 * a separate thread that is launched when GUI is started
 * 
 * @Author: Luke Howard
 * @Date: 13/10/2020
 */
public abstract class SwappingAlgorithms {
	private HashMap<String, Teams> algoTeams;
	private ArrayList< String> suggestedSwaps;
	
	public SwappingAlgorithms(HashMap<String, Teams> algoTeams) {
		this.algoTeams = algoTeams;
		suggestedSwaps = new ArrayList<String>();
	}
	
	public HashMap<String, Teams> getAlgoTeams() {return algoTeams;}
	public ArrayList<String> getSuggestedSwaps(){return suggestedSwaps;}
	
//	Methods to override
	abstract double calcSD();
	abstract void improveSD();

//	performs stdev check before and after swaps and checks that no hard team constraints are violated in the process
	public boolean swapStudents(Students s1, Teams best, Students s2, Teams worst) {
		double beforeSwap = calcSD();
		swapMembers(s1,s2,best,worst);
		double afterSwap  = calcSD();
		if(afterSwap >= beforeSwap) {
			swapMembers(s2,s1,best,worst);
			return false;
		}
		if(best.checkLeader()== true) {
			swapMembers(s2,s1,best,worst);
			return false;
		}
		if(worst.checkLeader()== true) {
			swapMembers(s2,s1,best,worst);
			return false;
		}
		else {
			String goodSwap = "Swap "+s1.getStud()+" with "+s2.getStud()+" to reduce stdev from "
					+beforeSwap+" to "+afterSwap;
			suggestedSwaps.add(goodSwap);	
			return true;
		}
	}
	
	public void swapMembers(Students s1, Students s2, Teams t1, Teams t2) {
		t1.removeMember(s1);
		t2.removeMember(s2);
		t1.addMembers(s2);
		t2.addMembers(s1);
	}
}

class PPalgorithm extends SwappingAlgorithms implements Runnable{
	
	public PPalgorithm(HashMap<String, Teams> algoTeams) {
		super(algoTeams);
		getSuggestedSwaps().add("=====Changes to reduce Percentage Preferences Standard Deviation=====");
	}
	
	@Override
	public double calcSD() {
		ArrayList<Double> totalprefs = new ArrayList<Double>();
		for(Map.Entry<String , Teams> m : getAlgoTeams().entrySet()) {
			Teams team = m.getValue();
			totalprefs.add(team.percentPref());
		}
		
		double mean = 0;
		double [] sumSquares = new double[totalprefs.size()];
		double totalSum = 0;
		for(double d : totalprefs) {
			mean += d;
		}
		mean = mean/totalprefs.size();
		
		for(int i = 0; i <totalprefs.size(); i++) {
			sumSquares[i] = Math.pow((totalprefs.get(i)-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		stdDev = Math.round(stdDev*100.0)/100.0;
		return stdDev;
	}

	@Override
	void improveSD() {
		Teams bestTeam = null;
		Teams worstTeam = null;
		int index = 1;
		TreeMap<Double, Teams> orderedTeams = new TreeMap<Double, Teams>();
		ArrayList<Teams> sortedTeams = new ArrayList<Teams>();
		
		for(Map.Entry<String, Teams> m : getAlgoTeams().entrySet()) {
			double teamPP = m.getValue().percentPref();
			Teams team = m.getValue();
			
			orderedTeams.put(teamPP, team);
		}
		
		for(Map.Entry<Double, Teams> m : orderedTeams.entrySet()) {
			sortedTeams.add(m.getValue());
		}
		
		bestTeam = sortedTeams.get(0);
		worstTeam = sortedTeams.get(sortedTeams.size()-index);	
		
		ArrayList<Students>	bestPPMembers = bestTeam.getMembers();
		ArrayList<Students> worstPPMembers = worstTeam.getMembers();
		
		int s1index = (int)(Math.random()*bestPPMembers.size());
		int s2index = (int)(Math.random()*worstPPMembers.size());
		Students s1 = null;
		Students s2 = null;
		if(!bestPPMembers.isEmpty() && !worstPPMembers.isEmpty()) {
			 s1 = bestPPMembers.get(s1index);
			 s2 = worstPPMembers.get(s2index);
			swapStudents(s1, bestTeam, s2, worstTeam);
			if(swapStudents(s1, bestTeam, s2, worstTeam)==false) {
				index++;
				if(sortedTeams.size()-index >0) {
					worstTeam = sortedTeams.get(sortedTeams.size()-index);
				}
			}
			bestPPMembers.remove(s1index);
			worstPPMembers.remove(s2index);
		}
	}
	
	@Override
	public void run() {
		int count = 0;
		while(calcSD() > 0.05) {
		improveSD();
		if(count > 200000) {
			break;
		}
		count++;
		}
		for(String s : getSuggestedSwaps()) {
			System.out.println(s);
		}
	}
}

class SSalgorithm extends SwappingAlgorithms implements Runnable{
	
	public SSalgorithm(HashMap<String, Teams> algoTeams) {
		super(algoTeams);
		getSuggestedSwaps().add("=====Changes to reduce Skill Shortfall Standard Deviation=====");
	}

	@Override
	public void run() {
		int count = 0;
		while(calcSD() > 0.05) {
			improveSD();
			count++;
			if(count > 200000) {
				break;
			}
		}
		
		for(String s : getSuggestedSwaps()) {
			System.out.println(s);
		}	
	}

	@Override
	double calcSD() {
		ArrayList<Double> totalSK = new ArrayList<Double>();
		for(Map.Entry<String , Teams> m : getAlgoTeams().entrySet()) {
			Teams team = m.getValue();
			totalSK.add(team.skillShorfall());
		}
		
		double mean = 0;
		double [] sumSquares = new double[totalSK.size()];
		double totalSum = 0;
		for(double d : totalSK) {
			mean += d;
		}
		mean = mean/totalSK.size();
		
		for(int i = 0; i <totalSK.size(); i++) {
			sumSquares[i] = Math.pow((totalSK.get(i)-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		stdDev = Math.round(stdDev*100.0)/100.0;
		return stdDev;
	}
	
	@Override
	void improveSD() {
		Teams bestTeam = null;
		Teams worstTeam = null;
		int index = 1;
		TreeMap<Double, Teams> orderedTeams = new TreeMap<Double, Teams>();
		ArrayList<Teams> sortedTeams = new ArrayList<Teams>();
		
		for(Map.Entry<String, Teams> m : getAlgoTeams().entrySet()) {
			double teamShortfall = m.getValue().skillShorfall();
			Teams team = m.getValue();
			
			orderedTeams.put(teamShortfall, team);
		}
		
		for(Map.Entry<Double, Teams> m : orderedTeams.entrySet()) {
			sortedTeams.add(m.getValue());
		}
		
		bestTeam = sortedTeams.get(0);
		worstTeam = sortedTeams.get(sortedTeams.size()-index);	
		ArrayList<Students>	bestMembers = bestTeam.getMembers();
		ArrayList<Students> worstMembers = worstTeam.getMembers();

		int s1index = (int)(Math.random()*bestMembers.size());
		int s2index = (int)(Math.random()*worstMembers.size());
		Students s1 = null;
		Students s2 = null;
		if(!bestMembers.isEmpty() && !worstMembers.isEmpty()) {
			s1 = bestMembers.get(s1index);
			s2 = worstMembers.get(s2index);
			if(swapStudents(s1, bestTeam, s2, worstTeam)==false) {
				index++;
				if(sortedTeams.size()-index >0) {
					worstTeam = sortedTeams.get(sortedTeams.size()-index);
				}
				
			}
		}
	}
	
}

class SCAlgorithm extends SwappingAlgorithms implements Runnable{
	
	public SCAlgorithm(HashMap<String, Teams> algoTeams) {
		super(algoTeams);
		getSuggestedSwaps().add("=====Changes to reduce Skill Competency Standard Deviation=====");
	}

	@Override
	public void run() {
		int count = 0;
		while(calcSD() > 0.05) {
			improveSD();
			count++;
			if(count > 200000) {
				break;
			}
		}
		
		for(String s : getSuggestedSwaps()) {
			System.out.println(s);
		}
		
	}

	@Override
	double calcSD() {
		ArrayList<Double> totalSC = new ArrayList<Double>();
		for(Map.Entry<String , Teams> m : getAlgoTeams().entrySet()) {
			Teams team = m.getValue();
			totalSC.add(team.skillCompt());
		}
		
		double mean = 0;
		double [] sumSquares = new double[totalSC.size()];
		double totalSum = 0;
		for(double d : totalSC) {
			mean += d;
		}
		mean = mean/totalSC.size();
		
		for(int i = 0; i <totalSC.size(); i++) {
			sumSquares[i] = Math.pow((totalSC.get(i)-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		stdDev = Math.round(stdDev*100.0)/100.0;
		return stdDev;
	}
	
	@Override
	void improveSD() {
		Teams bestTeam = null;
		Teams worstTeam = null;
		int index = 1;
		TreeMap<Double, Teams> orderedTeams = new TreeMap<Double, Teams>();
		ArrayList<Teams> sortedTeams = new ArrayList<Teams>();
		
		for(Map.Entry<String, Teams> m : getAlgoTeams().entrySet()) {
			double teamSkillCompt = m.getValue().skillCompt();
			Teams team = m.getValue();
			
			orderedTeams.put(teamSkillCompt, team);
		}
		
		for(Map.Entry<Double, Teams> m : orderedTeams.entrySet()) {
			sortedTeams.add(m.getValue());
		}
		bestTeam = sortedTeams.get(0);
		worstTeam = sortedTeams.get(sortedTeams.size()-index);	
		ArrayList<Students>	bestMembers = bestTeam.getMembers();
		ArrayList<Students> worstMembers = worstTeam.getMembers();

		int s1index = (int)(Math.random()*bestMembers.size());
		int s2index = (int)(Math.random()*worstMembers.size());
		Students s1 = null;
		Students s2 = null;
		if(!bestMembers.isEmpty() && !worstMembers.isEmpty()) {
			s1 = bestMembers.get(s1index);
			s2 = worstMembers.get(s2index);
			if(swapStudents(s1, bestTeam, s2, worstTeam)==false) {
				index++;
				if(sortedTeams.size()-index >0) {
					worstTeam = sortedTeams.get(sortedTeams.size()-index);
				}
				
			}
		}
	}	
}

