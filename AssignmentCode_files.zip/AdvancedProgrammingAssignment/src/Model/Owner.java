package Model;
import java.io.Serializable;
import java.util.*;
/*
 * contains all information related to owner objects as well as print method used to write these objects to file
 * 
 * @Author: Luke Howard
 * @Date: 8/10/20
 */
public class Owner  implements Serializable {
	private static final long serialVersionUID = 1L;	
	private String FName;
	private String LName;
	private String ownerID;
	private String role;
	private String email;
	private String compID;
	private ArrayList<Project> projects;
	
	public Owner (String first, String last, String ownerID, String role, String email, String compID){
		FName = first;
		LName = last;
		this.ownerID = "own"+ownerID;
		this.role = role;
		this.email = email;
		this.compID = "C"+compID;
		projects = new ArrayList<Project>();
	}
	
//	Accesor methods for Owner class
	public String getFirst (){
		return FName;
	}
	
	public String getLast(){
		return LName;
	}
	
	public String getOwner(){
		return ownerID;
	}
	
	public String getRole(){
		return role;
	}
	
	public String getEmail(){
		return email;
	}
	
	public String getComp(){
		return compID;
	}
	
//  method to add project to project owners array list
	public void addProject(Project p){
		projects.add(p);
	}
	
	public String print() {
		String A =getOwner()+"\n"+getFirst()+"\n"+getLast()+
				"\n"+getRole()+"\n"+getEmail()+"\n"+getComp();
		return A;
	}
}
