package Model;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import StudentSwap.StudentSwapController;

/*
 * This is the main model class for the GUI. Contains data about teams and students as well as instances of 
 * algorithm threads, undo button command manager and database writer. Controls the manipulation of data and 
 * student swaps as required from controller. Contains methods to swap students and update teams accordingly. Will 
 * update swaps in serialised format and into database. Also retrieves stddev and team metrics to be displayed in 
 * graphs
 * 
 * @Author: Luke Howard
 * @Date: 13/10/2020
 */
 public class TeamsModel{
	private StudentSwapController SWC;
	private HashMap<String, Teams> totalTeams;
	private HashMap<String, Students> interviewedStudents;
	private ArrayList<Students> membersToSwap;
	private ReadWrite rw;
	private Thread ppThread;
	private Thread ssThread;
	private Thread scThread;
	private CommandManager cm;
	private DataBaseWriter dbw;
	
	public TeamsModel() {
		rw = new ReadWrite();
		totalTeams = rw.readTeams();
		interviewedStudents = rw.readInterveiwed();
		membersToSwap = new ArrayList<Students>();
		ppThread = new Thread( new PPalgorithm(rw.readTeams()));
		ssThread = new Thread( new SSalgorithm(rw.readTeams()));
		scThread = new Thread (new SCAlgorithm(rw.readTeams()));
		cm = CommandManager.getInstance();
		}
	
	public void setController(StudentSwapController SWC) {this.SWC = SWC;}

//  Accessor methods
	public  HashMap<String, Teams> getCurrentTeams(){
		return this.totalTeams;
	}
	
	public Students getStudID(String ID) {
		for(Map.Entry<String, Students> m : interviewedStudents.entrySet()) {
			if(m.getKey().equalsIgnoreCase(ID)) {
				return m.getValue();				
				}
		}
		return null;
	}
	
	public String getTeam(Students stud) {
		for(Map.Entry<String , Teams> m : totalTeams.entrySet()) {
		String teamID =	m.getValue().containsMember(stud);
			if(teamID != null)
			return teamID;
		}
		return null;
	}
	
	public Teams setTeam(String team) {
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if(m.getKey().equalsIgnoreCase(team)){
				return m.getValue();
			}
		}
		return null;
	}

	public String[] getMembers(String teamName) {
		ArrayList<Students> teamMembers = new ArrayList<Students>();
		String [] members = new String[4];
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if(m.getKey().equalsIgnoreCase(teamName)) {
				Teams t = m.getValue();
				teamMembers = t.getMembers();
				members[0] = teamMembers.get(0).getStud()+" - "+teamMembers.get(0).getPersonality();
				members[1] = teamMembers.get(1).getStud()+" - "+teamMembers.get(1).getPersonality();
				members[2] = teamMembers.get(2).getStud()+" - "+teamMembers.get(2).getPersonality();
				members[3] = teamMembers.get(3).getStud()+" - "+teamMembers.get(3).getPersonality();
			}	
		}
		return members;
	}

	public Teams getTeam(String ID) {
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if (m.getKey().equalsIgnoreCase(ID)){
				Teams team = m.getValue();
				return team;
			}
		}
		return null;
	}
	
	public void startThread() throws InterruptedException{
		ppThread.start();
		ssThread.start();
		scThread.start();
		ppThread.join();
		ssThread.join();
		
	}
	
	public String printTeam(Teams team) {
		String toPrint = "Information for "+team.getTeamID()+"\nProject Description: "+team.getProject().getDesc()+
				"\nProgramming rating: "+team.getProject().getProgram()+"\nAnalytics rating: "+team.getProject().getAnalytics()+
				"\nWeb Applications rating: "+team.getProject().getApp()+"\nNetowrking rating: "+team.getProject().getNetwork();
		return toPrint;
	}
	
	public void writeTeams() {
		rw.writeTeams(totalTeams);
	}

//  Methods for swapping team members and updating view
	public void addToSwap(Students member) throws Exception {	
		if(membersToSwap.size() >=2) {
				throw new Exception ();
			}
		else membersToSwap.add(member);
	}
	
	public void swapMembersGUI() {
		Students student1 = membersToSwap.get(0);
		Students student2 = membersToSwap.get(1);
		String teamToFind = getTeam(student1);
		String teamToFind2 = getTeam(student2);
		
		Teams team1 = setTeam(teamToFind);
		Teams team2 = setTeam(teamToFind2);
		addUndo(student1,student2);
		swapMembers(student1, student2, team1, team2);
		
	}
	public void swapMembers(Students s1, Students s2, Teams t1, Teams t2) {
		t1.removeMember(s1);
		t2.removeMember(s2);
		t1.addMembers(s2);
		t2.addMembers(s1);
	}
	public void undoswapMembers(Students s1, Students s2, Teams t1, Teams t2) {
		t1.removeMember(s1);
		t2.removeMember(s2);
		t1.addMembers(s2);
		t2.addMembers(s1);
	}
	
	public boolean removeMember(Students member) {
		for(Students s : membersToSwap) {
			if(s.getStud().equalsIgnoreCase(member.getStud())){
				membersToSwap.remove(member);
				return true;
			}
		}
		return false;
	}
	
	public void removeAll() {membersToSwap.clear();}
	
	public ArrayList<Students> suggestedStudents(Teams team){
		Project project = team.getProject();
		ArrayList<Students> suggestedStudents = new ArrayList<Students>();
		for(Map.Entry<String, Students> m : interviewedStudents.entrySet()) {
			Students s = m.getValue();
			String pref1 = s.getPref1();
			String pref2 = s.getPref2();

			if(pref1.equalsIgnoreCase(project.getProjID()) || pref2.equalsIgnoreCase(project.getProjID())) {
				suggestedStudents.add(s);
			}
		}			
		return suggestedStudents;
	}

//  Methods used for ensuring hard constraints aren't violated
	public void checkMembers() throws Exception {
		if(membersToSwap != null) {
			Students student1 = membersToSwap.get(0);
			Students student2 = membersToSwap.get(1);
			String teamToFind = getTeam(student1);
			String teamToFind2 = getTeam(student2);
			
			Teams team1 = setTeam(teamToFind);
			Teams team2 = setTeam(teamToFind2);
			
			if(checkConflicts(student2, team1.getMembers()) == true) {
				throw new Exception();
			}
			
			if(checkConflicts(student1, team2.getMembers()) == true) {
				throw new Exception();
			}
			addUndo(student1,student2);
			swapMembers(student1, student2, team1, team2);
		}
	}
	
	public boolean checkConflicts(Students ID, ArrayList<Students> members) {
		boolean conflict = false;
		for(Students s : members) {
			if(ID.getStud().equals(s.getConflict1())||ID.getStud().equals(s.getConflict2())) {
				conflict = true;
				return conflict;
			}
			if(s.getStud().equals(ID.getConflict1())||s.getStud().equals(ID.getConflict2())) {
				conflict = true;
				return conflict;
			}
		}
		return conflict;
	}
	
	public boolean checkSameTeam() {
		Students student1 = membersToSwap.get(0);
		Students student2 = membersToSwap.get(1);
		String team1 = getTeam(student1);
		String team2 = getTeam(student2);
		
		if(team1.equalsIgnoreCase(team2)) {
			return true;
		}
		return false;
	}
	
	public boolean checkLeader() {
		boolean leader = false;
		Students student1 = membersToSwap.get(0);
		Students student2 = membersToSwap.get(1);
		String teamToFind = getTeam(student1);
		String teamToFind2 = getTeam(student2);
		
		Teams team1 = setTeam(teamToFind);
		Teams team2 = setTeam(teamToFind2);
		swapMembers(student1, student2, team1, team2);
		
		if(team1.checkLeader() == true) {
			swapMembers(student2, student1, team1, team2);
			leader = true;
			return leader;
		}
		if(team2.checkLeader() == true) {
			swapMembers(student2, student1, team1, team2);
			leader = true;
			return leader;
		}
		return leader;
	}
	
	public boolean checkPeronalities() {
		boolean personalities = false;
		Students student1 = membersToSwap.get(0);
		Students student2 = membersToSwap.get(1);
		String teamToFind = getTeam(student1);
		String teamToFind2 = getTeam(student2);
		
		Teams team1 = setTeam(teamToFind);
		Teams team2 = setTeam(teamToFind2);
		swapMembers(student1, student2, team1, team2);
		
		if(team1.checkPersonality() == true) {
			swapMembers(student2, student1, team1, team2);
			personalities = true;
		}
		if(team2.checkPersonality() == true) {
			swapMembers(student2, student1, team1, team2);
			personalities = true;
		}
		return personalities;
	}
	

//  calculating different team metrics, calls method from teams object
	public Double getPP(String teamName) {
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if(m.getKey().equalsIgnoreCase(teamName)) {
				Teams t = m.getValue();
				return t.percentPref();
			}
		}
		return null;
	}

	public Double getSS(String teamName) {
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if(m.getKey().equalsIgnoreCase(teamName)) {
				Teams t = m.getValue();
				return t.skillShorfall();
			}
		}
		return null;
	}

	public Double getSC (String teamName) {
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			if(m.getKey().equalsIgnoreCase(teamName)) {
				Teams t = m.getValue();
				return t.skillCompt();
			}
		}
		return null;
		
	}

//  Calculates stdev of each team metric 
	public double calPPstdev() {
		PPalgorithm pp = new PPalgorithm(totalTeams);
		return pp.calcSD();
	}

	public double calSKdev() {
		SSalgorithm ss = new SSalgorithm(totalTeams);
		return ss.calcSD();
	}

	public double calSCdev() {
		SCAlgorithm sc = new SCAlgorithm(totalTeams);
		return sc.calcSD();
	}
	
//  DataBase Methods
	public void writeDB() {
		ArrayList<Teams> teamsToWrite = new ArrayList<Teams>();
		ArrayList<Students> studentsToWrite = new ArrayList<Students>();
		for(Map.Entry<String, Teams> m: totalTeams.entrySet()) {
			Teams team = m.getValue();
			teamsToWrite.add(team);
		}
		for(Map.Entry<String, Students> m: interviewedStudents.entrySet()) {
			Students stud = m.getValue();
			studentsToWrite.add(stud);
		}
		DataBaseWriter dbw = new DataBaseWriter(teamsToWrite, studentsToWrite);		
	}
	
//  Undo methods
	public void addUndo(Students s1, Students s2) {
		ArrayList<Students> undoToAdd = new ArrayList<Students>();
		undoToAdd.add(s1);
		undoToAdd.add(s2);
		cm.addUndo(undoToAdd);
	}
	
	public void undo() {
		ArrayList<Students> undoToComplete = cm.undo();
		Students s1 = undoToComplete.get(0);
		Students s2 = undoToComplete.get(1);
		Teams s1Team = null;
		Teams s2Team = null;
		
		for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
			Teams team = m.getValue();
			ArrayList<Students> currentMembers = team.getMembers();
			for(Students s : currentMembers) {
				if(s.getStud().equalsIgnoreCase(s1.getStud())) {
					s1Team = team;
				}
				if(s.getStud().equalsIgnoreCase(s2.getStud())) {
					s2Team = team;
				}
			}
		}
		
		undoswapMembers(s1,s2,s1Team,s2Team);
	}
	
	public int checkUndoSize() {
		return cm.getSize();
	}
}


