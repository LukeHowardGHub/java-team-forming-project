package Model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * Class writes team and student objects to database. Creates all required tables and has the potential to be
 * Expanded to write tables regarding company, owner, project etc. Is passed arrayLists of students and Teams when
 * created. Contains print method that user can pass table name to and will print
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */
public class DataBaseWriter {
	String url = "jdbc:sqlite:/Users/lukehoward/eclipse-workspace/AdvancedProgrammingAssignment/teamsDB";
	Connection conn;
	Statement st;
	ResultSet rs;
	ArrayList<Teams> totalTeams;
	ArrayList<Students> totalStudents;
	
	public DataBaseWriter(ArrayList<Teams> teams, ArrayList<Students> students) {
		totalTeams = teams;
		totalStudents = students;
		try {
			conn = DriverManager.getConnection(url);
			st = conn.createStatement();
			rs = null;
			dropTables();
			createTables();
			populateteams();
			populateStudents();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void dropTables() {
		try {
		st.executeUpdate("drop table if exists Students");
		st.executeUpdate("drop table if exists Companies");
		st.executeUpdate("drop table if exists Owners");
		st.executeUpdate("drop table if exists Projects");
		st.executeUpdate("drop table if exists 'Student Preferences'");
		st.executeUpdate("drop table if exists Teams");
		}
		catch(SQLException se) {
	         System.out.println("SQLError: " + se.getMessage () + " code: " + 
                    se.getErrorCode ());
	         se.printStackTrace();

		}
	}

	public void createTables() {
		try {
		st.executeUpdate("create table Students(ID varchar(40) primary key, "
				+ "'Programming Grade' number,"
				+ "'Networking Grade' number,"
				+ "'Analytics Grade' number,"
				+ "'Web Grade' number,"
				+ "Personality char(1),"
				+ "'Conflict 1' varchar(20),"
				+ "'Conflict 2' varchar(20)) ");
		st.executeUpdate("create table Companies (ID varchar(40) primary key,"
				+ "'Company Name' varchar(100),"
				+ "ABN number,"
				+ "WebSite varchar(100),"
				+ "Address varchar(100))");
		st.executeUpdate("create table Owners(ID varchar(40) primary key,"
				+ "'First Name' varchar(40),"
				+ "'Last Name' varchar(40),"
				+ "Role varchar(40),"
				+ "Email varchar(100),"
				+ "Comapny varchar(40)) ");
		st.executeUpdate("create table Projects (ID varchar(40) primary key,"
				+ "'Project Title' varchar(100),"
				+ "'Project Description' varchar(100),"
				+ "'Owner ID' varchar(40),"
				+ "'Programming rank' number,"
				+ "'Networking Rank' number,"
				+ "'Analytics Rank' number,"
				+ "'Applications Rank' number ) ");
		st.executeUpdate("create table 'Student Preferences' (ID varchar(40) primary key,"
				+ "'Preference 1' varchar(40),"
				+ "'Preference 2' varchar(40),"
				+ "'Preference 3' varchar(40),"
				+ "'Preference 4' varchar(40))");
		st.executeUpdate("create table Teams (ID varchar(50) primary key,"
				+ "'Project ID' varchar(50),"
				+ "'Member 1' varchar(40),"
				+ "'Member 2' varchar(40),"
				+ "'Member 3' varchar(40),"
				+ "'Member 4' varchar(40))");
		}
		catch(SQLException se) {
	         System.out.println("SQLError: " + se.getMessage () + " code: " + 
                   se.getErrorCode ());
	         se.printStackTrace();
		}
	}
	
	public void populateteams() {
		try {
		PreparedStatement pst = conn.prepareStatement("INSERT INTO Teams VALUES (?,?,?,?,?,?)");
			for(Teams t: totalTeams) {
					pst.setString(1,t.getTeamID());
					pst.setString(2, t.getProject().getProjID());
					ArrayList<Students> members = t.getMembers();
					pst.setString(3, members.get(0).getStud()); 
					pst.setString(4, members.get(1).getStud());
					pst.setString(5, members.get(2).getStud()); 
					pst.setString(6, members.get(3).getStud() ); 
					pst.executeUpdate();
				}	
			}
			catch(SQLException sql) {
				sql.printStackTrace();
		}
	}
	
	public void populateStudents() {
		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO Students values (?,?,?,?,?,?,?,?)");
				for(Students s: totalStudents) {
					pst.setString(1, s.getStud());
		    		pst.setInt(2, s.getProgGrade());
		    		pst.setInt(3, s.getNetGrade());
		    		pst.setInt(4, s.getAnaGrade());
		    		pst.setInt(5, s.getWebGrade());
		    		pst.setString(6, String.valueOf(s.getPersonality()));
		    		pst.setString(7, s.getConflict1());
		    		pst.setString(8, s.getConflict2());  
					pst.executeUpdate();
					}	
				}
				catch(SQLException sql) {
					sql.printStackTrace();
			}
	}
	
	public void displayTable(String table) {
		System.out.println("displaying "+table+" table");
		try {
			ResultSet rs = st.executeQuery("select * from "+table);
			ResultSetMetaData rsmeta = rs.getMetaData();
			
			for(int i = 1; i <= rsmeta.getColumnCount(); i++) {
				System.out.printf("%-20s", rsmeta.getColumnName(i));
				}	
			System.out.println();
			while(rs.next()) {
				for (int i = 1; i <= rsmeta.getColumnCount(); i++) {
					System.out.printf("%-20s", rs.getString(i));
				}
				System.out.println();
			}
			System.out.println();
		}
		catch(SQLException sqle) {
			sqle.getMessage();
		}
	}
}
