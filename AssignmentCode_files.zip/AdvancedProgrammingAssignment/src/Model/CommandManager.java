package Model;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
/*
 * class controls undo button from GUI by storing students in an arrayList and passing/recalling these from the stack
 * class contained below. Singleton pattern is used to ensure only one instance can be created
 * 
 * @author: Luke Howard
 * @date: 8/10/2020
 */
class CommandManager {
	private static CommandManager cm = null;
	private Stack<ArrayList<Students>> stackUndo;
	
	private CommandManager() {
		stackUndo = new Stack<ArrayList<Students>>();
		}
	
	public static CommandManager getInstance() {
		if( cm != null) {
			return cm;
		}
		return new CommandManager();
	}
	
	public void addUndo(ArrayList<Students> add) {
		stackUndo.push(add);
		}
	
	public ArrayList<Students> undo(){
		if(stackUndo.getSize()>0) {
			ArrayList<Students> undos = stackUndo.pop();
			return undos;
		}
		else return null;
	}
	
	public int getSize() {
		return stackUndo.getSize();
	}
	
}
/*
 * class stores arrayLists of students that can be recalled from the top of the stack by undo button in student
 * swapping GUI
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */
class Stack<T>{
	private List<ArrayList<Students>> undoList;
	
	Stack(){
		undoList = new LinkedList<>();
	}
	
	public void push(ArrayList<Students> swaps){
		
		undoList.add(undoList.size(),swaps);
	}
	
	public ArrayList<Students> pop(){
		if(undoList.size()>0) {
			return undoList.remove(undoList.size()-1);
		}
		else return null;
	}
	
	public int getSize() {return undoList.size();}
}
