package Model;
import java.io.Serializable;

/*
 * class contains all information relevant to project objects. Methods to print information (used in file writing)
 * compareTo() method created so projects could be ordered
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */

public class Project implements Comparable<Project>,Serializable {
	private static final long serialVersionUID = 1L;	
	private String title;
	private String projectID;
	private String desc;
	private String ownerID;
	private int programming;
	private int networking;
	private int analytics;
	private int applications;


	public Project( String title, String projID, String desc, String ownID, int programming, int networking, 
					int analytics, int applications){
					this.title = title;
					projectID = "proj"+projID;
					this.desc = desc;
					ownerID = "own"+ownID;
					this.programming = programming;
					this.networking = networking;
					this.analytics = analytics;
					this.applications = applications;	
	}
					
//	Accessor methods for project class
	public String getTitle(){
		return title;
	}
	
	public String getProjID(){
		return projectID;
	}
	
	public String getDesc(){
		return desc;
	}
	
	public String getOwnID(){
		return ownerID;
	}
	
	public int getProgram(){
		return programming;
	}
	
	public int getNetwork(){
		return networking;
	}
	
	public int getAnalytics(){
		return analytics;
	}	
	
	public int getApp(){
		return applications;
	}
	
	public String print() {
		String A = getProjID()+"\n"+getTitle()+"\n"+
	getDesc()+"\n"+getOwnID()+"\n"+getProgram()+"\n"+getNetwork()
	+"\n"+getAnalytics()+"\n"+getApp();
		return A;
	}

	@Override
	public int compareTo(Project obj) {
		return  projectID.compareTo(obj.projectID);
	}
}
