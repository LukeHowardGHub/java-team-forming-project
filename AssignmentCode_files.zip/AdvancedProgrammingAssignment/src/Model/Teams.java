package Model;
import java.io.Serializable;
import java.util.ArrayList;
/*
 * Teams class contains all information relevant to team objects. Arraylist of students is used to contain 
 * team members. Methods to calculate team metrics are contained here, as well as methods to adjust members of the 
 * team
 * 
 * @Author; Luke Howard
 * @Date: 13/10/2020
 */
public class Teams implements Serializable {
	private static final long serialVersionUID = 1L;
	private String teamID;
	private Project project;
	private ArrayList<Students> TeamMembers;
	
	public Teams(String ID, Project project){
		teamID = ID;
		this.project = project;
		TeamMembers =new ArrayList<Students>();
		
	}
	public String getTeamID() {return teamID;}
	public Project getProject() {return project;}
	public ArrayList<Students> getMembers(){return TeamMembers;}
	
//	Member adjustment methods
	public void addMembers(Students memeber) {TeamMembers.add(memeber);}
	public void clearMembers() {TeamMembers.clear();}

	public String containsMember(Students stud) {
		String ID = stud.getStud(); 
		for(Students s : TeamMembers) {
			String student = s.getStud();
			if(student.equals(ID)) {
				return teamID;
			}
		}
		return null;
	}
	
	public void removeMember(Students student) {
		String ID = student.getStud();
		int index = 0;
		for(Students s : TeamMembers) {
			String stud = s.getStud();
			if(stud.equals(ID)) {
				index = TeamMembers.indexOf(s);
			}
		}
		TeamMembers.remove(index);
	}

//	Team Metric calculation methods
	public double[] calcAvgCompt() {
		double [] averages = new double[4];
		double prog =0;
		double net = 0;
		double ana = 0;
		double web = 0;
		
		for(Students s : TeamMembers) {
			prog += s.getProgGrade();
		}
		averages[0] = prog/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			net += s.getNetGrade();
		}
		averages[1] = net/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			ana += s.getAnaGrade();
		}
		averages[2] = ana/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			web+= s.getWebGrade();
		}
		averages[3] = web/(TeamMembers.size());
		
		return averages;
		}
	
	public double skillCompt() {
		double [] averages = new double[4];
		double prog =0;
		double net = 0;
		double ana = 0;
		double web = 0;
		
		for(Students s : TeamMembers) {
			prog += s.getProgGrade();
		}
		averages[0] = prog/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			net += s.getNetGrade();
		}
		averages[1] = net/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			ana += s.getAnaGrade();
		}
		averages[2] = ana/(TeamMembers.size());
		
		for(Students s : TeamMembers) {
			web+= s.getWebGrade();
		}
		averages[3] = web/(TeamMembers.size());
		
		double totalAvg = 0;
		for(double d : averages) {
			totalAvg += d;
		}
		totalAvg = totalAvg/averages.length;
		
		return totalAvg;
		}
	
	public double skillCompSD() {
		double averages [] = calcAvgCompt();
		double mean = 0;
		double [] sumSquares = new double[averages.length];
		double totalSum = 0;
		
		for(double d : averages ) {
			mean += d;
		}
		mean = mean/averages.length;
		
		for(int i = 0; i <averages.length; i++) {
			sumSquares[i] = Math.pow((averages[i]-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		return stdDev;
		}
	
	public double percentPref() {
		double count = 0;
		double gotPref;
		Project ID = getProject();
		for (Students s : TeamMembers) {
			if(s.getPref1().equals(ID.getProjID())||s.getPref2().equals(ID.getProjID())) {
				count++;
			}
		}
		gotPref = count/(TeamMembers.size());
		return gotPref;
		}
	
	public double percentPrefSD() {
		double averages [] = new double[TeamMembers.size()];
		Project project = getProject();
		double mean = 0;
		double [] sumSquares = new double[averages.length];
		double totalSum = 0;
		
		for(int i = 0; i < TeamMembers.size(); i++) {
			String pref1 = TeamMembers.get(i).getPref1();
			String pref2 = TeamMembers.get(i).getPref2();
			if(pref1.equals(project.getProjID()) || pref2.equals(project.getProjID())) {
				averages[i] = 1;
			}else averages[i] = 0;	
		}
		for(double d : averages ) {
			mean += d;
		}
		mean = mean/averages.length;
		
		for(int i = 0; i <averages.length; i++) {
			sumSquares[i] = Math.pow((averages[i]-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		return stdDev;
		}
	
	public double skillShorfall() {
		double shortfall = 0;
		double [] requirements = new double [4];
		double [] skills = calcAvgCompt();
		Project p = getProject(); 
		
		requirements[0] = p.getProgram();
		requirements[1] = p.getNetwork();
		requirements[2] = p.getAnalytics();
		requirements[3] = p.getApp();
		
		for (int i = 0; i < requirements.length; i++) {
			if(skills[i] < requirements[i]) {
				double difference = requirements[i] - skills[i];
				shortfall += difference;
			}
		}
		return shortfall;
		}
	
	public double skillShorfallSD() {
		double [] requirements = new double [4];
		double [] skills = calcAvgCompt();
		double [] difference = new double[TeamMembers.size()];
		double mean = 0;
		double [] sumSquares = new double[difference.length];
		double totalSum = 0;
		Project p = getProject(); 
		
		requirements[0] = p.getProgram();
		requirements[1] = p.getNetwork();
		requirements[2] = p.getAnalytics();
		requirements[3] = p.getApp();
		
		for (int i = 0; i < requirements.length; i++) {
			difference[i] = requirements[i] - skills[i];
		}
		
		for(double d : difference ) {
			mean += d;
		}
		mean = mean/difference.length;
		
		for(int i = 0; i <difference.length; i++) {
			sumSquares[i] = Math.pow((difference[i]-mean), 2);
		}
		
		for(double d : sumSquares) {
			totalSum += d;
		}
		
		double stdDev = Math.sqrt(totalSum/sumSquares.length);
		return stdDev;
		}
		
//  Print methods
	public String print() {
		Project p = getProject();
		String A = getTeamID()+" "+p.getProjID();
		A = A + printMembers();
		return A;
				
	}
	
	public String printMembers() {
		String A = "";
		for(Students s : TeamMembers) {
			A = A+" "+s.getStud();
		}
		return A;
	}
	
//	Constraint check methods
	public boolean checkLeader() {
		ArrayList<Character> personalities = new ArrayList<Character>();
		for(Students s : TeamMembers) {
			personalities.add(s.getPersonality());
		}
		
		if (!personalities.contains('A')) {
			return true;
		}
		else return false;
		}
	
	public boolean checkPersonality() {
		ArrayList<Character> personalities = new ArrayList<Character>();
		for(Students s : TeamMembers) {
			personalities.add(s.getPersonality());
		}
		if(((personalities.contains('A')) &&(personalities.contains('B')) && (personalities.contains('C'))||
				((personalities.contains('A')) &&(personalities.contains('B')) && (personalities.contains('D')))||
				((personalities.contains('A')) &&(personalities.contains('D')) && (personalities.contains('C'))))) {
			return false;
		}
		return true;
		}
}

