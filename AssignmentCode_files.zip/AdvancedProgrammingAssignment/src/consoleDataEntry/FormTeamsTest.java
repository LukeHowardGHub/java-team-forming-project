package consoleDataEntry;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Model.Project;
import Model.Students;
import Model.Teams;

/*
 * JUnit test cases for testing hard constraints about personality types, leader presence, conflicts as well as 
 * the calculation of team balance metrics  
 * 
 *  @Author: Luke Howard
 *  @Date: 8/10/2020
 */
public class FormTeamsTest {
	Utility newUtil = new Utility();
	Teams team;
	Students stud1;
	Students stud2;
	Students stud3;
	Students stud4;
	Students stud5;
	Students stud6;
	Project proj;
	
	@Before
	public void setUp() throws Exception {
		stud1 = new Students("s1", 4,3,2,1,"S16","s19","proj4","proj3","proj2","proj1",'A');
		stud2 = new Students("s2", 2,3,4,1,"S18","s19","proj4","proj3","proj2","proj1",'B');
		stud3 = new Students("s3", 3,3,1,1,"S17","s20","proj2","proj9","proj10","proj7",'C');
		stud4 = new Students("s4", 2,3,2,1,"S16","s19","proj3","proj6","proj2","proj8",'D');
		stud5 = new Students("s5", 4,3,2,1,"S2","","proj4","proj3","proj2","proj1",'B');
		stud6 = new Students("s6", 4,3,2,1,"","","proj4","proj3","proj2","proj1",'B');
		proj = new Project("Test Project 4", "4", "Test Project 4", "4", 4, 3, 2, 1);
		team = new Teams ("Team1", proj);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSkillCompetancy() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		double actualAvg = 0;
		double testAvg = 0;
		double [] actual  = {2.75,3,2.25,1};
		double [] test = team.calcAvgCompt();
		
		for(double d : actual) {
			actualAvg += d;
		}
		actualAvg = actualAvg/actual.length;
		
		for(double d : test) {
			testAvg += d;
		}
		
		testAvg = testAvg / test.length;
		assertEquals(actualAvg,testAvg,0.001);
	}
	
	@Test
	public void testPercentagePref() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		double test = team.percentPref();
		double actual = 0.5;
		
		assertEquals(actual,test,0.001);
	}
	
	@Test
	public void testSkillShortfall() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		double test = team.skillShorfall();
		double actual = 1.25;
		
		assertEquals(actual, test, 0.001);
	}
	
	@Test
	public void testStudentConflict () {
		HashMap<String, Students> members = new HashMap<String, Students>();
		members.put(stud1.getStud(),stud1);
		members.put(stud2.getStud(),stud2);
		
		boolean conflict = newUtil.checkConflicts(stud5, members);
		assertFalse(conflict);
	}
	
	@Test (expected = NoLeaderException.class)
	public void testNoLeader () throws NoLeaderException{
		ArrayList<Character> personalities = new ArrayList<Character>();
		HashMap<String, Students> members = new HashMap<String, Students>();
		members.put(stud2.getStud(),stud2);
		members.put(stud3.getStud(),stud3);
		members.put(stud4.getStud(),stud4);
		members.put(stud6.getStud(),stud6);
		
		for(Map.Entry<String, Students> m : members.entrySet()) {
			Students s = m.getValue();
			char personality = s.getPersonality();
			personalities.add(personality);
		}
		
		if(!(personalities.contains('A'))) {
			throw new NoLeaderException();
		}

	}
	
	@Test (expected = PersonalityImbalance.class)
	public void testPersonalityImbalance() throws PersonalityImbalance {
		team.addMembers(stud6);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		newUtil.checkPersonalityImbalance(team);
	}
	
	@Test (expected = DoubleUpException.class)
	public void testRepeatedMember() throws DoubleUpException {
		HashMap<String, Students> members = new HashMap<String, Students>();
		members.put(stud2.getStud(),stud2);
		members.put(stud3.getStud(),stud3);
		members.put(stud4.getStud(),stud4);
		
		Students ID = stud2;
		
		newUtil.checkMembers(members, ID, team);
	}
	
	@Test (expected = InvalidMember.class)
	public void testInvalidMember() throws InvalidMember{
		team.addMembers(stud6);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		newUtil.addAllocatedMembers(stud2.getStud(), stud2);
		
		newUtil.checkInvalidMember(team);
	}
	
	@Test
	public void testSkillCompSD() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		assertEquals(0.771,team.skillCompSD(),0.001);
	}
	
	@Test
	public void testProjMembersSD() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);

		assertEquals(0.5,team.percentPrefSD(),0.01);
	}
	
	@Test
	public void testskillShortfallSD() {
		team.addMembers(stud1);
		team.addMembers(stud2);
		team.addMembers(stud3);
		team.addMembers(stud4);
		
		assertEquals(0.586, team.skillShorfallSD(),0.001);
	}
}

