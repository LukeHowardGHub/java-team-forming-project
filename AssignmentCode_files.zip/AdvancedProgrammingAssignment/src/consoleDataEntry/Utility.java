package consoleDataEntry;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import com.sun.source.tree.MemberSelectTree;

import Model.Company;
import Model.Owner;
import Model.Project;
import Model.ReadWrite;
import Model.Students;
import Model.Teams;
import StudentSwap.StudentSwapController;
/*
 * main data handling class for the console data entry and main menu. Contains collections of all objects created by
 * the user and passes them to writing class to be printed to text file. Checks for hard constraint violation when
 * user is forming teams and also contains methods for metric calculation.
 * 
 * @Author: Luke Howard
 * @Date: 13/10/2020
 */
public class Utility{
	private HashMap<String, Company> totalCompany;
	private HashMap<String, Owner> totalOwners;
	private HashMap<String,Project> totalProjects;
	private HashMap<String, Students> totalStudents;
	private HashMap<String, Teams> totalTeams;
	private ArrayList <Project> finalProjects;
	private HashMap<String, Students> interviewedStudents;
	private HashMap<String, Students> allocatedMembers;
	ReadWrite rw = new ReadWrite();
	StudentSwapController SWC = null;
	Scanner input;
	
	public Utility() {
		 totalCompany = new HashMap<String, Company>();
		 totalOwners = new HashMap<String, Owner>();
		 totalProjects = new HashMap<String, Project>();
		 totalStudents =  new HashMap<String, Students>();
		 totalTeams = new HashMap<String, Teams>();
		 interviewedStudents = new HashMap<String, Students>();
		 allocatedMembers= new HashMap<String, Students>();
		 input = new Scanner(System.in);
	}
	
//		Methods to put instances of objects formed into appropriate collection
		public void addCompany(String ID,Company newComp) {totalCompany.put(ID, newComp);}
		public void addOwner(String ID, Owner newOwn) {totalOwners.put(ID, newOwn);}
		public void addProject(String ID, Project newProj) {totalProjects.put(ID, newProj);	}
		public void addStudents (String ID, Students newStudent) {totalStudents.put(ID,newStudent);}
		public void addTeams(String ID, Teams newTeam) {totalTeams.put(ID, newTeam);}
		public void addInterveiwed(String ID, Students student) {interviewedStudents.put(ID, student);}
		public void addAllocatedMembers(String ID, Students student) {allocatedMembers.put(ID, student);}
	
//		Data entry methods
		public void enterComapny() {
			boolean found = false;	
			System.out.println("Enter company ID: \nC");
			String id = input.nextLine();
			System.out.println("Enter Company Name:");
			String name = input.nextLine();
			System.out.println("Enter Company ABN:");
			String ABN = input.nextLine();
			System.out.println("Enter Company URL:");
			String URL = input.nextLine();
			System.out.println("Enter Company Address:");
			String address = input.nextLine();
			
			if(id.isEmpty()|| name.isEmpty() ||ABN.isEmpty() || URL.isEmpty() || address.isEmpty()) {
				System.err.println("Cannot have null input. Please try again");
				return;
				}
//			checks if entered ID has been previously used and lets user decide if they want to overwrite
			String IDtoFind = id;
			found = checkcompID(IDtoFind);
			if (found == false) {
			Company newComp = new Company (id, name, ABN, URL, address);
			addCompany(id,newComp);
			writeCompany();
			}
			else {
				System.out.println("Company ID already in use. Would you like to overwrite?\nEnter Y or N");
				char answer = Character.toUpperCase(input.nextLine().charAt(0));
				if(answer == 'Y') {
					Company newComp = new Company (id, name, ABN, URL, address);
					addCompany(id,newComp);
					writeCompany();
				}
			}	
		}
		
		public void enterOwner() {
			try {
				System.out.println("Enter First Name:");
				String first = input.nextLine();
				
				System.out.println("Enter Last Name:");
				String last = input.nextLine();
				
				System.out.println("Enter Project Owner ID: \nOwn");
				String ownID = input.nextLine();
				
				System.out.println("Enter Role:");
				String role = input.nextLine();
				
				System.out.println("Enter Email:");
				String email = input.nextLine();
				
				System.out.println("Enter Company ID: \nC");
				String compID = input.nextLine();
				
				if(first.isEmpty()|| last.isEmpty() ||ownID.isEmpty() || role.isEmpty() || 
						email.isEmpty()|| compID.isEmpty()) {
					System.err.println("Cannot have null input. Please try again");
					return;
				}
//				check for already created owner with same ID
				String ownIDtoFind = ownID;
				boolean found = checkOwnID(ownIDtoFind);
				if (found == false) {
				Owner newOwn = new Owner (first, last, ownID, role, email, compID);
				addOwner(ownID, newOwn);
				writeOwner();
				}
				
				else {
					System.out.println("Owner ID already in use. Would you like to overwrite?\nEnter Y or N");
					char answer = Character.toUpperCase(input.nextLine().charAt(0));
					if(answer == 'Y') {
						Owner newOwn = new Owner (first, last, ownID, role, email, compID);
						addOwner(ownID, newOwn);
						writeOwner();
					}
				}
				}
				catch (Exception e) {
					System.err.println("Error in owner details. Please try again");
				}
		}

		public void enterProject() {
			try {
				System.out.println("Enter Project Title:");
				String title = input.nextLine();
				
				System.out.println("Enter Project ID: \nproj");
				String projID = input.nextLine();
				
				System.out.println("Enter Project Description");
				String desc = input.nextLine();
				
				System.out.println("Enter Owner ID: \nOwn");
				String ownID2 = input.nextLine();
				
				if(title.isEmpty()|| projID.isEmpty() ||desc.isEmpty() || ownID2.isEmpty()) {
					System.err.println("Cannot have null input. Please try again");
					return;
				}
//				user enters project skill preferences 
				ArrayList<Integer> preferences = new ArrayList<Integer>();
				System.out.println("Please rate following from 1 to 4 with 4 being the highest:");
				System.out.println();
				System.out.println("Enter Project and Software Engineering priority:");
				int program = Integer.parseInt((input.nextLine()));
				preferences.add(program);
				if(program <1 || program >4) {
					throw new Exception();
				}
				
				System.out.println("Enter Newtworking & Security priority:");
				int network = Integer.parseInt((input.nextLine()));
				if(network <1 || network >4) {
					throw new Exception();
				}
				if(!(preferences.contains(network))) {
					preferences.add(network);
				}
				else throw new DoubleUpException();
				
				System.out.println("Enter Analytics & Big Data priority:");
				int analytics= Integer.parseInt((input.nextLine()));
				if(analytics <1 || analytics >4) {
					throw new Exception();
				}
				if(!(preferences.contains(analytics))) {
					preferences.add(analytics);
				}
				else throw new DoubleUpException();
				
				System.out.println("Enter Web & Mobile Applications priority:");
				int web = Integer.parseInt((input.nextLine()));
				if(web <1 || web >4) {
					throw new Exception();
				}
				if(!(preferences.contains(web))) {
					preferences.add(web);
				}
				else throw new DoubleUpException();

//				checks for already created projects with same ID and lets user overwrite
				String projIDtoFind = projID;
				boolean found = checkProjID(projIDtoFind);
				if (found == false) {
				Project newProj = new Project (title, projID, desc, ownID2, program, network, analytics, web);
				addProject(projID, newProj);
				writeProject(newProj);
				}
				else {
					System.out.println("Project ID already in use. Would you like to overwrite?\nEnter Y or N");
					char answer = Character.toUpperCase(input.nextLine().charAt(0));
					if(answer == 'Y') {
						Project newProj = new Project (title, projID, desc, ownID2, program, network, analytics, web);
						addProject(projID, newProj);
						writeProject(newProj);
					}
				  }
				}
				catch(DoubleUpException e) {
					System.err.println("Cannot enter the same preference twice ");
				}
				catch(Exception invalid) {
					System.err.println("Skills rating must be between 1 and 4. Please try again.");
				}

		}
//      METHODS TO CALL WRITE METHODS IN READWRITWE CLASS AND PASS APPROPRIATE MAP, SERIALISE OBJECTS
		public void writeCompany(){rw.writeCompanies(totalCompany);}
		public void writeProject(Project newProj) {rw.writeProject(newProj);}
		public void writeOwner() {rw.writeOwner(totalOwners);}
		public void serialiseprojects() {rw.writeProject(totalProjects);}
		public void serialiseStudents() {rw.writeInterviewedStudents(interviewedStudents);}
		public void serialiseTeams() {rw.writeTeams(totalTeams);}
		public void writeTeams() {rw.writeTeamstxt(totalTeams);}
		
		public void sumPref() {
			try {
			TreeMap<Integer, Project> ProjectsToRemove = new TreeMap<Integer, Project>();
			TreeMap<Project, Integer> ProjectsToPrint = new TreeMap<Project, Integer>();
			ArrayList<Project> finalProject = new ArrayList<Project>();
			Map.Entry<Integer, Project>  Print;
			
			for(Map.Entry<String, Project> m : totalProjects.entrySet()) {
				Project p = m.getValue();
				String IDtoFind;
				Scanner input = new Scanner(new File("preferences.txt"));
				IDtoFind = p.getProjID();
				int sum = 0;
				while(input.hasNext()) {
					if(input.next().equals(IDtoFind)) {
						sum += input.nextInt();
					}
				}
				int total = sum;
				ProjectsToRemove.put(total, p);
			}

			int projectsNeeded = (totalStudents.size())/4;
			do {
			Print= ProjectsToRemove.lastEntry();
			ProjectsToPrint.put(Print.getValue(),Print.getKey());
			finalProject.add(Print.getValue());
			ProjectsToRemove.remove(Print.getKey());
			}while(ProjectsToPrint.size()<= (projectsNeeded-1));
			
			rw.writeProject(ProjectsToPrint);
			rw.writeFinalProject(finalProject);			
			}
			catch(Exception e) {System.err.println("Unable to find project ID in file");}
		}
		
//      METHODS TO ADD SERIALISED OBJECTS AND READ IN STUDENTS.TXT	
		public void addStudents(){
			try {
			Scanner input = new Scanner (new File("students.txt"));
			while (input.hasNextLine()) {
				String studID = input.next();
				input.next();
				int prog = Integer.parseInt(input.next());
				input.next();
				int network = Integer.parseInt(input.next());
				input.next();
				int analytics = Integer.parseInt(input.next());
				input.next();
				int web = Integer.parseInt(input.next());
				
				Students student = new Students (studID, prog, network, analytics, web);
				addStudents(studID, student);
			 }
		}
			catch (IOException e) {System.err.println("unable to read students.txt file");}
		}
		
		public void readProjects() {
			totalProjects = rw.readProjects();
		}
		
		public void readTeams() {
			totalTeams = rw.readTeams();
		}
		
		public void readFinalProjects() {
			finalProjects = rw.readFinalProjects();
		}
		
		public void readInterveiwed() {
			interviewedStudents = rw.readInterveiwed();
		}
		
//      METHODS RELATING TO STUDENT PERSONALITIES		
		public void interviewStud() {
			String choice;
			Scanner sc = new Scanner(System.in);
			try {
				do {
				System.out.println("Which student would you like to enter preferences for? \n Enter to exit");
				for (Map.Entry<String, Students> m : totalStudents.entrySet()) {
					Students s = m.getValue();
					System.out.println(s.getStud());
				}
				System.out.println();
				System.out.println("Previously Interveiwed Students: ");
				for(Map.Entry<String, Students> m : interviewedStudents.entrySet()) {
					System.out.println(m.getKey());
				}
				
		     System.out.println("Selection: ");    
			 choice = sc.nextLine().toUpperCase();
		     if(choice.isEmpty()) {break;}
		     else {
		      Students ID = totalStudents.get(choice);
		      boolean found = rw.checkInterviewID(ID);
		      
		       if(found == false) {
		    	  addInterview(ID);
			      }
		      else {
		    	 System.out.println("Current personality and conflicts: ");
		    	 System.out.println("Personality: "+ID.getPersonality());
		    	 System.out.println("Conflict 1: "+ID.getConflict1()+" "+"Conflict 2: "+ID.getConflict2());
		    	 System.out.println();
		    	 rw.ammendInterview(ID);
		    	 addInterview(ID);
		         }
			  }
			}while(!(choice.isEmpty()));
			}
			catch(IOException e) {System.out.println("Unable to ammend personalities");}
			catch (Exception e) {System.err.println("Invalid selection. Please try again");}
		}
		
		public void addInterview(Students ID) {
			Scanner sc = new Scanner(System.in);
			String previous;
			try {
				System.out.println("Enter Personality type for "+ID.getStud());
				System.out.println("Must be of type A,B,C or D");
				System.out.println("Personality types must not exceed 5");
				rw.availablePersonality();
				char type = Character.toUpperCase(sc.nextLine().charAt(0));
				if(type != 'A'&& type!='B'&& type!='C'&& type!= 'D') {
					throw new Exception();
				}
				else {ID.setPersonality(type);}
				
				System.out.println("Enter ID first student conflict:");
				String stud1 = sc.nextLine().toUpperCase();
				if(stud1.equals(ID.getStud())) {
					throw new SelfSelect();
				}
				else {
				 ID.setConflict1(stud1);
				 previous = stud1;
				}
				
				System.out.println("Enter ID second student conflict:");
				String stud2 = sc.nextLine().toUpperCase();
				if(stud2.equals(previous)) {throw new DoubleUpException();}
				if(stud2.equals(ID.getStud())){throw new SelfSelect();}
				else {
					if(stud2.isEmpty()) {
						stud2 = "NA";
						ID.setConflict2(stud2);
					}
					ID.setConflict2(stud2);
					}
				addInterveiwed(ID.getStud(),ID);
				rw.writeStudInfo(ID);
			}
			catch(DoubleUpException e) {e.print();}
			catch(SelfSelect e) {e.print();}
			catch(Exception e) {System.err.println("Error in selection. Please try again");}
			}

//      METHODS RELATED TO STUDENT PROJECT PREFERENCES 	
		public void studPref() {
			String choice;
			Scanner sc = new Scanner(System.in);
			try {
				do {
				System.out.println("Which student would you like to enter preferences for? \n Enter to exit");
				for (Map.Entry<String, Students> m : totalStudents.entrySet()) {
					Students s = m.getValue();
					System.out.println(s.getStud());
				}
				
		    System.out.println("Selection: ");    
			choice = sc.nextLine().toUpperCase();
		    if(choice.isEmpty()) {break; }
		    else {
		    	Students ID = totalStudents.get(choice);
		    	boolean found = rw.checkPrefID(ID);
		     
		    	if(found == false) {addPreferences(ID);}
		    	else {
		    	 rw.ammendPref(ID);
		    	 addPreferences(ID);
		    	}
			  }
			}while(!(choice.isEmpty()));
			}
			catch (Exception e) {System.err.println("Invalid selection. Please try again");}
		}
		
		private void addPreferences(Students ID) {
			Scanner sc = new Scanner(System.in);
			System.out.println("List of avilable projects:");
			boolean found;
			for(Map.Entry<String, Project> m : totalProjects.entrySet()) {
				Project p = m.getValue();
				System.out.println(p.getProjID());
				System.out.println();
			}
			try {
			while(found = true){
			ArrayList<String> projPref = new ArrayList<String>();
			System.out.println("Enter projectID number only");	
			System.out.println("Enter project for perference 1\nproj");
			
			String pref1 = "proj"+sc.nextLine();
			found = checkProj(pref1);
			if(!(projPref.contains(pref1))){projPref.add(pref1);}
			else throw new DoubleUpException();
			
			System.out.println("Enter project for perference 2\nproj");
			String pref2 = "proj"+sc.nextLine();
			found = checkProj(pref2);
			if(!(projPref.contains(pref2))){projPref.add(pref2);}
			else throw new DoubleUpException();
			
			System.out.println("Enter project for perference 3\nproj");
			String pref3 = "proj"+sc.nextLine();
			found = checkProj(pref3);
			if(!(projPref.contains(pref3))){projPref.add(pref3);}
			else throw new DoubleUpException();
			
			System.out.println("Enter project for perference 4\nproj");
			String pref4 = "proj"+sc.nextLine();
			found = checkProj(pref4);
			if(!(projPref.contains(pref4))){projPref.add(pref4);}
			else throw new DoubleUpException();
			
			if(found == false) {
				System.out.println("Cannot select unavailable project");
				break;
				}
			
			ID.setPreferences(pref1, pref2, pref3, pref4);
			rw.writeStudPref(ID);
			interviewedStudents.put(ID.getStud(), ID);
			break;
			}
			}
			catch(DoubleUpException e) {e.print();}
		}

//      METHODS TO FIND AND CHECK IF IDS EXIST IN COLLECTIONS
		private boolean checkProj(String pref1) {
			boolean found = false;
			for(Map.Entry<String, Project> m : totalProjects.entrySet()) {
				Project p = m.getValue();
				if(p.getProjID().equals(pref1)) {
					 found = true;
					return found;
				}else found = false;
			}
			return found;
		}

		public boolean checkcompID(String id) {
			boolean found = totalCompany.containsKey(id);
			return found;
		}
		
		public boolean checkOwnID(String id) {
			boolean found = totalOwners.containsKey(id);
			return found;
		}
		
		public boolean checkProjID(String id) {
			boolean found = totalProjects.containsKey(id);
			return found;
		}
		
		public boolean checkFinalProjID(String id) {
			boolean found = false;
			System.out.println("Finding "+id+"...");
			for(Project p : finalProjects) {
				if(p.getProjID().equalsIgnoreCase(id)) {
					System.out.println("FOUND");
					System.out.println();
					found = true;
					return found;
				}
				
			}
			return found;
		}
		
		private Project getProject(String ID) {
			Project project;
			for (Project p : finalProjects) {
				if(p.getProjID().equalsIgnoreCase(ID)) {
					project = p;
					return project;
				}
			}
			return null;
		}

//      METHODS RELATED TO FORMING TEAMS		
		public Teams formTeam(){
		try {
		if(totalTeams != null) {
			ArrayList<Project> formedTeams = checkFormedTeams();
			formedTeams.forEach((p) -> finalProjects.remove(p));
		}
		Scanner input = new Scanner(System.in);
		Project teamProj;
		String TeamID = "Team"+(totalTeams.size()+1);

		System.out.println("Select projID for team to build \nPress 0 to exit");
		System.out.println();
		finalProjects.forEach((p) -> {System.out.println("ProjID: "+p.getProjID()+"\nDescription: "+p.getDesc());
									  System.out.println();
		});
		
		System.out.println("proj");
		String ID = "proj"+input.next();
		if(ID.equals("proj0")) { return null;}
		boolean found = checkFinalProjID(ID);
		
		if(found == false) {throw new Exception();} 
		teamProj = getProject(ID);
		
		Teams newTeam = new Teams(TeamID,teamProj);
		totalTeams.put(TeamID, newTeam);
		return newTeam;	
		}
		catch(Exception e) {System.err.println("**Unable to select project**");}
		return null;
		}
		
		public void addMembers(Teams team) {
			try {
			addAllocated();

			Scanner input = new Scanner(System.in);
			Project teamProj = team.getProject();
			int count = 1;
			String choice;
			HashMap<String, Students> members = new HashMap<String, Students>();
			ArrayList<Character> personalities = new ArrayList<Character>();
			
			System.out.println("Suggested students: \nStudents who preferenced this project");
			ArrayList<Students> suggestedStudents = suggestedStudents(teamProj);
			for(Students s : suggestedStudents) {
				System.out.println(s.print());
			}
			System.out.println();
			
			System.out.println("Available Students:");
			for (Map.Entry<String, Students> m : interviewedStudents.entrySet()){
				Students s = m.getValue();
				if(!(allocatedMembers.containsKey(s.getStud()))) {System.out.println(s.print());}
				}
			
			do {
			System.out.println("Enter Student ID of team member "+(count));
			if(!(members.isEmpty())) {
				System.out.println("Current memebers: ");
				for(Map.Entry<String, Students> m : members.entrySet()) {
					Students s = m.getValue();
					System.out.println(m.getKey()+" Conflicts: "+s.getConflict1()+" "+s.getConflict2()
					+" "+s.getPersonality());
					}
				}
			
			System.out.println("Selection: ");    
			choice = input.nextLine().toUpperCase();
		    if(choice.isEmpty()) {return; }
		    
		    Students ID = interviewedStudents.get(choice);
		    boolean conflict = checkConflicts(ID, members);
		    checkMembers(members, ID, team); 
		   
		     
		     if( conflict == true) {
		    	 System.out.println("Conflicts with other members exist...Add member anyway?\n"
		    	 		+ "Enter Y or N");
		    	 char choice2 =  Character.toUpperCase(input.nextLine().charAt(0));
		    	 if(choice2 == 'N') {
		    		 totalTeams.remove(team.getTeamID());
			    	 throw new StudentConflict();
		    	 }
		    	 
		     }
		     team.addMembers(ID);
			 members.put(ID.getStud(),ID);
			 personalities.add(ID.getPersonality());
			 count++;
		}while(count < 5);
			
			checkLeader(team, personalities);
			checkPersonalityImbalance(team);
			checkInvalidMember(team);
			
			for (Map.Entry<String, Students> m : members.entrySet()) {
				Students s = m.getValue();
				allocatedMembers.put(s.getStud(), s);
				}
			}
			catch(DoubleUpException e) {e.print();}
			catch(StudentConflict e) {e.print();}
			catch(NoLeaderException e) {e.print();}
			catch(PersonalityImbalance e) {e.print();}
			catch(InvalidMember e) {e.print();}
			catch(Exception e) {System.err.println("**Invalid selection**");}
			
			
		}
		
		public ArrayList<Project> checkFormedTeams() {
			ArrayList<Project> projToRemove = new ArrayList<Project>();
			for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
				Teams t = m.getValue();
				Project p = t.getProject();
				for(Project proj : finalProjects){
					if(proj.getProjID().equals(p.getProjID())) {
						projToRemove.add(proj);
						}
					}
				}
			return projToRemove;
		}
		
		public void addAllocated(){
			ArrayList <Students> studToAdd = new ArrayList <Students>();
			for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
				Teams t = m.getValue();
				studToAdd = t.getMembers();
				studToAdd.forEach((s) -> allocatedMembers.put(s.getStud(), s));
			}
		}
		
		public void checkInvalidMember(Teams team) throws InvalidMember{
			ArrayList<Students> members = team.getMembers();
			
			for(Students s : members) {
				if(allocatedMembers.containsKey(s.getStud())) {
					throw new InvalidMember();
				}
			}
			
		}

		public void checkLeader(Teams team, ArrayList<Character> personalities) throws NoLeaderException {
			if(!(personalities.contains('A'))) {
				team.clearMembers();
				totalTeams.remove(team.getTeamID());
				throw new NoLeaderException();
			}
			
		}

		public void checkMembers(HashMap<String, Students> members, Students ID, Teams team) throws DoubleUpException{
			 if(members.containsValue(ID)) {
				totalTeams.remove(team.getTeamID());
		    	throw new DoubleUpException();
		     	}
		}

		public void checkPersonalityImbalance(Teams team) throws PersonalityImbalance {
			ArrayList<Character> personalities = new ArrayList<Character>();
			ArrayList<Students> members = team.getMembers();
			
			for(Students s : members) {
			personalities.add(s.getPersonality());
			}
			
			if(((personalities.contains('A')) &&(personalities.contains('B')) && (personalities.contains('C'))||
					((personalities.contains('A')) &&(personalities.contains('B')) && (personalities.contains('D')))||
					((personalities.contains('A')) &&(personalities.contains('D')) && (personalities.contains('C'))))) {
				return;
			}
			else {throw new PersonalityImbalance();}
		}

		public boolean checkConflicts(Students ID, HashMap<String, Students> members) {
			boolean conflict = false;
			for(Map.Entry<String, Students> m : members.entrySet()) {
				Students s = m.getValue();
				if(ID.getStud().equals(s.getConflict1())||ID.getStud().equals(s.getConflict2())) {
					conflict = true;
					return conflict;
				}
				if(s.getStud().equals(ID.getConflict1())||s.getStud().equals(ID.getConflict2())) {
					conflict = true;
					return conflict;
				}
			}
			return conflict;
		}
		
		public ArrayList<Students> suggestedStudents(Project project){
			ArrayList<Students> suggestedStudents = new ArrayList<Students>();
			for(Map.Entry<String, Students> m : interviewedStudents.entrySet()) {
				Students s = m.getValue();
				String pref1 = s.getPref1();
				String pref2 = s.getPref2();
				String pref3 = s.getPref3();
				String pref4 = s.getPref4();
				
				if(pref1.equalsIgnoreCase(project.getProjID()) || pref2.equalsIgnoreCase(project.getProjID()) || 
						pref3.equalsIgnoreCase(project.getProjID()) || pref4.equalsIgnoreCase(project.getProjID()) ) {
					if(!(allocatedMembers.containsValue(s))) {
						suggestedStudents.add(s);
					}
				}
			}			
			return suggestedStudents;
		}

//      METHODS RELATED TO TEAM METRICS		
		public void SkillCompentency() {
			for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
				Teams team = m.getValue();
				double avg[] = team.calcAvgCompt();
				System.out.println(team.getTeamID());
				System.out.println("Average Programming skill: "+avg[0]);
				System.out.println("Average Networking skill: "+avg[1]);
				System.out.println("Average Analytics skill: "+avg[2]);
				System.out.println("Average Web applications skill: "+avg[3]);
				System.out.println();
			}
		}
		
		public void PercentagePref() {
			for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
				Teams team = m.getValue();
				System.out.println(team.getTeamID()+": "+team.percentPref());
			}
			
		}
		
		public void SkillShortfall() {
			for(Map.Entry<String, Teams> m : totalTeams.entrySet()) {
				Teams team = m.getValue();
				System.out.println(team.getTeamID()+": "+team.skillShorfall());
			}
			
		}
		
		public boolean checkTeams() {
			if(totalTeams.size() >= 1) {
				return true;
			}
			return false;
		}
	}	
		
//EXCEPTION CLASSES
class DoubleUpException extends Exception{
	public void print(){
		System.err.println("**Can not enter the same preference twice**");
	}
}
	
class InvalidMember extends Exception{
	public void print() {
		System.err.println("**Student has already been allocated to another team. Team formation Cancelled**");
	}
}

class StudentConflict extends Exception{
	public void print(){
		System.err.println("**Student has conflicts with allocated members**");
	}
}

class PersonalityImbalance extends Exception{
	public void print() {
		System.err.println("**Team has less than 3 personality types**");
	}
}

class NoLeaderException extends Exception{
	public void print() {
		System.err.println("**Team does not contain leader personality type**");
	}
}

class SelfSelect extends Exception{
	public void print() {
		System.err.println("**Students cannot select themselves");
	}
	
class InvalidSelection extends Exception{
	public void print() {
		System.err.println("**Invalid Selection**");
		}
	}
}
