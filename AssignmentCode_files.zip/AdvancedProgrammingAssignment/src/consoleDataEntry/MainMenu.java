package consoleDataEntry;
import java.util.ArrayList;

/*
 * Main menu for console based user entry of company, owner, project and student objects. Uses switch statement to
 * allow user to select which option they wish to perform. Also allows user to write preferences and teams to file.
 * Displays team metrics when teams have been formed.
 * 
 * @newUtility: instance of Utility class which serves as main data handler for main menu. Contains all collections
 * of variables created and calls methods to read and write preformed objects.
 * 
 * @Author: Luke Howard
 * @Date: 8/10/2020
 */
import java.util.Scanner;

import Model.Project;
import Model.Teams;

import java.io.*;

public class MainMenu {
	public static void main(String[] args) {
		Utility newUtil = new Utility();
		boolean valid = false;
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
	    int option = 0;
	    boolean check = true;
		
	    newUtil.addStudents();
	    newUtil.readProjects();
	    newUtil.readInterveiwed();
	    newUtil.readFinalProjects();
//	    newUtil.readTeams();
	    
	    while (check) {
	    do {
	          try{
	              System.out.println("========MENU=========");
	              System.out.println("Enter Your option");
	              System.out.println("1. Add Company");
	              System.out.println("2. Add Project owner");
	              System.out.println("3. Add Project");
	              System.out.println("4. Capture Student Personalities");
	              System.out.println("5. Add Student preferences");
	              System.out.println("6. Shortlist projects");
	              System.out.println("7. Form Teams");
	              System.out.println("8. Team Metrics");
	              System.out.println("9. Quit");
	              System.out.println("=================");

	              String ans = input.nextLine();
	              option = Integer.parseInt(ans);
	              
	              if (option>0  && option <10) valid = true;
	              else throw new Exception();
	              }
	              catch (Exception e){
	                System.err.println("Error. Please re-enter a valid selection");
	              }
	         		} while (valid == false);
		
		switch (option) {
//		Option for entering and creating company object
		case 1:
			newUtil.enterComapny();
			break;
	
//		option for entering and creating owner object	
		case 2:
			newUtil.enterOwner();
			break;

//		option for entering and creating project objects	
		case 3: 
			newUtil.enterProject();
			break;
//		option to update students conflicts and personality type
		case 4:
			newUtil.interviewStud();
			break;

//		option to update student project preferences 	
		case 5:
			newUtil.studPref();
			break;
			
//		option to shortlist top preferenced projects and write them to file	
		case 6:
			newUtil.sumPref();
			break;
			
//		option to create new team from interviewed students 
		case 7:
			Teams team = newUtil.formTeam();
			if(team == null) {break;}
			newUtil.addMembers(team);
			break;

//		option to check team meatric, contains sub menu with nested switch statement 	
		case 8:
//			if not enough teams have been formed, team metric menu will not be enabled to the user
			boolean check2 = false;
			if(newUtil.checkTeams() == false) {
				System.err.println("Unable to compute metrics until all teams are formed");
				break;
			}
			
			System.out.println("Which metric would you like to view?");
			do {
				try {
				 System.out.println("========Metrics=========");
	              System.out.println("Enter Your option");
	              System.out.println("1. Average Student Skill compentency");
	              System.out.println("2. Percentage Preferences");
	              System.out.println("3. Skill Shortfall");
	              
	              option = Integer.parseInt(input.nextLine());
	              if (option>0  && option <4) check = true;
	              else throw new Exception();
	              }
	              catch (Exception e){
	                System.err.println("Error. Please re-enter a valid selection");
	              }
			} while(check == false);
			
			switch(option) {
//			options below show team metric requested by the user for each team that has been formed
			case 1:
				newUtil.SkillCompentency();
				break;
			
			case 2:
				newUtil.PercentagePref();
				break;
			
			case 3:
				newUtil.SkillShortfall();
				break;
			}
			break;
//		exit the program, writes the required files upon exiting	
		case 9:
			System.out.println("Goodbye");
			newUtil.serialiseprojects();
			newUtil.serialiseStudents();
			newUtil.serialiseTeams();
			newUtil.writeTeams();
			System.exit(0);
		}

	}
	}	
}
